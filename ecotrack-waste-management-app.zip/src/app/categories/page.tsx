"use client";

import { useState } from "react";
import { Database, ShieldAlert } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card } from "@/components/ConfirmDialog";
import { WASTE_CATEGORIES } from "@/lib/categories";

export default function CategoriesPage() {
  const { records, notify, settings: userSettings, saveSettings } = useDataStore();
  const [seeding, setSeeding] = useState(false);

  const seed = async () => {
    setSeeding(true);
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to seed");
      notify("success", `Loaded ${data.seeded ?? 0} sample records.`);
      window.location.reload();
    } catch (err) {
      notify("error", (err as Error).message);
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
          Categories
        </p>
        <h2 className="text-2xl font-bold tracking-tight">Waste categories reference</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Ten waste categories supported by EcoTrack. Each record belongs to exactly one category, and
          recycling, composting, and disposal are tracked separately through the status field.
        </p>
      </div>

      <Card>
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h3 className="text-sm font-semibold">Sample dataset</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Populate EcoTrack with a small set of clearly-marked sample records. {records.length > 0
                ? "Records already exist, so seeding is a no-op."
                : "Use this to explore the dashboard, charts and reports without entering data by hand."}
            </p>
          </div>
          <button
            type="button"
            onClick={seed}
            disabled={seeding}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-60"
          >
            <Database className="h-4 w-4" /> {seeding ? "Loading…" : "Load sample data"}
          </button>
        </div>
      </Card>

      <section className="grid gap-4 md:grid-cols-2">
        {WASTE_CATEGORIES.map((c) => (
          <Card key={c.key}>
            <div className="flex items-start gap-3">
              <span
                className="mt-1 h-3 w-3 flex-shrink-0 rounded-full"
                style={{ background: c.color }}
                aria-hidden
              />
              <div className="flex-1">
                <h3 className="text-base font-semibold">{c.label}</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300">{c.description}</p>
                {c.safetyNote && (
                  <div className="mt-2 flex items-start gap-2 rounded-lg border border-rose-300 bg-rose-50 p-2 text-xs text-rose-700 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-200">
                    <ShieldAlert className="mt-0.5 h-4 w-4" />
                    <p>{c.safetyNote}</p>
                  </div>
                )}
                <div className="mt-2 flex flex-wrap gap-2 text-xs">
                  <span
                    className={`rounded-full px-2 py-0.5 ${
                      c.isRecyclable
                        ? "bg-sky-500/10 text-sky-700 dark:text-sky-300"
                        : "bg-slate-500/10 text-slate-600 dark:text-slate-300"
                    }`}
                  >
                    {c.isRecyclable ? "Recyclable category" : "Not a recyclable category"}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 ${
                      c.isOrganic
                        ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300"
                        : "bg-slate-500/10 text-slate-600 dark:text-slate-300"
                    }`}
                  >
                    {c.isOrganic ? "Organic / compostable" : "Not organic"}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </section>

      <Card>
        <h3 className="text-sm font-semibold">Notes on classification</h3>
        <ul className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
          <li>• A record in the “Recyclable”, “Plastic”, “Paper”, “Glass”, “Metal” or “e-waste” category is not automatically counted as recycled. Recycling status is tracked separately via the status field.</li>
          <li>• Diverted waste combines recycled, composted, in-process, and donation statuses.</li>
          <li>• e-waste and hazardous waste are flagged separately so the safety guidance appears whenever they are chosen in the form.</li>
        </ul>
      </Card>
    </div>
  );
}