"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  ArrowDownToLine,
  Calendar,
  Leaf,
  Loader2,
  Plus,
  Recycle,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card, StatCard } from "@/components/ConfirmDialog";
import {
  DateRangeFilter,
  formatDate,
  type DateRangeValue,
} from "@/components/DateRangeFilter";
import { RecordForm } from "@/components/Forms";
import {
  byCategory,
  byDay,
  byMonth,
  generateRecommendations,
  isInDateRange,
  recyclingVsDisposal,
  summarise,
} from "@/lib/calculations";
import { WASTE_CATEGORIES } from "@/lib/categories";

export default function HomePage() {
  const { records, loading, error, refresh } = useDataStore();
  const [range, setRange] = useState<DateRangeValue>({ start: null, end: null });
  const [openForm, setOpenForm] = useState(false);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const filtered = useMemo(
    () => records.filter((r) => isInDateRange(r.collectionDate, range.start, range.end)),
    [records, range],
  );

  const summary = useMemo(() => summarise(filtered), [filtered]);
  const daily = useMemo(() => byDay(filtered), [filtered]);
  const monthly = useMemo(() => byMonth(filtered), [filtered]);
  const categoryBreakdown = useMemo(() => byCategory(filtered), [filtered]);
  const recyclingVs = useMemo(() => recyclingVsDisposal(monthly), [monthly]);
  const recs = useMemo(() => generateRecommendations(filtered, []), [filtered]);

  const periodLabel = (() => {
    if (!range.start && !range.end) return "All recorded data";
    const s = range.start ? formatDate(range.start) : "Start";
    const e = range.end ? formatDate(range.end) : "Today";
    return `${s} → ${e}`;
  })();

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Dashboard
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Waste & recycling overview</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Live summary based on records you enter. <span className="font-medium">{periodLabel}</span>.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <DateRangeFilter value={range} onChange={setRange} />
          <button
            type="button"
            onClick={() => setOpenForm(true)}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
          >
            <Plus className="h-4 w-4" />
            Add record
          </button>
        </div>
      </div>

      {loading ? (
        <Card>
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading sample data…
          </div>
        </Card>
      ) : error ? (
        <Card>
          <p className="text-sm text-rose-600">Could not load data: {error}</p>
        </Card>
      ) : records.length === 0 ? (
        <Card>
          <div className="flex flex-col items-start gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <h3 className="text-base font-semibold">No records yet</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Start by logging a waste collection. Sample data can be loaded on the categories page.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setOpenForm(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
            >
              <Plus className="h-4 w-4" /> Add first record
            </button>
          </div>
        </Card>
      ) : (
        <>
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Total waste collected"
              value={summary.totalKg.toFixed(1)}
              unit="kg"
              icon={<Trash2 className="h-5 w-5" />}
              color="emerald"
              trend={`${summary.recordCount} records`}
            />
            <StatCard
              label="Recyclable waste"
              value={summary.recyclableKg.toFixed(1)}
              unit="kg"
              icon={<Recycle className="h-5 w-5" />}
              color="sky"
              trend={`${((summary.recyclableKg / Math.max(summary.totalKg, 1)) * 100).toFixed(1)}% of total`}
            />
            <StatCard
              label="Organic waste"
              value={summary.organicKg.toFixed(1)}
              unit="kg"
              icon={<Leaf className="h-5 w-5" />}
              color="emerald"
              trend={`${((summary.organicKg / Math.max(summary.totalKg, 1)) * 100).toFixed(1)}% of total`}
            />
            <StatCard
              label="Dry waste"
              value={summary.dryKg.toFixed(1)}
              unit="kg"
              icon={<Trash2 className="h-5 w-5" />}
              color="amber"
              trend={`${((summary.dryKg / Math.max(summary.totalKg, 1)) * 100).toFixed(1)}% of total`}
            />
            <StatCard
              label="Waste diverted from disposal"
              value={summary.divertedKg.toFixed(1)}
              unit="kg"
              icon={<ArrowDownToLine className="h-5 w-5" />}
              color="violet"
              trend={`${summary.diversionRate.toFixed(1)}% diversion rate`}
            />
            <StatCard
              label="Recycled / composted"
              value={(summary.recycledKg + summary.compostedKg).toFixed(1)}
              unit="kg"
              icon={<Sparkles className="h-5 w-5" />}
              color="emerald"
              trend={`Recycle ${summary.recyclingRate.toFixed(1)}% · Compost ${summary.compostingRate.toFixed(1)}%`}
            />
            <StatCard
              label="Sent for disposal"
              value={summary.disposedKg.toFixed(1)}
              unit="kg"
              icon={<Trash2 className="h-5 w-5" />}
              color="rose"
              trend="Records with status 'Disposed'"
            />
            <StatCard
              label="Period summary"
              value={summary.recordCount}
              unit="records"
              icon={<Calendar className="h-5 w-5" />}
              color="slate"
              trend={periodLabel}
            />
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <Card>
              <header className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold">Waste by category</h3>
                <span className="text-xs text-slate-500">Distribution</span>
              </header>
              {categoryBreakdown.length === 0 ? (
                <EmptyChart />
              ) : (
                <div className="h-64">
                  <ResponsiveContainer>
                    <PieChart>
                      <Pie
                        data={categoryBreakdown}
                        dataKey="totalKg"
                        nameKey="label"
                        innerRadius={48}
                        outerRadius={88}
                        paddingAngle={2}
                      >
                        {categoryBreakdown.map((entry) => (
                          <Cell key={entry.category} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value, _name, props) => [
                          `${Number(value ?? 0).toFixed(1)} kg`,
                          (props as { payload?: { label?: string } }).payload?.label ?? "",
                        ]}
                        contentStyle={tooltipStyle}
                      />
                      <Legend wrapperStyle={legendStyle} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card>
              <header className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold">Category-wise totals (kg)</h3>
                <span className="text-xs text-slate-500">Bar</span>
              </header>
              {categoryBreakdown.length === 0 ? (
                <EmptyChart />
              ) : (
                <div className="h-64">
                  <ResponsiveContainer>
                    <BarChart data={categoryBreakdown}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={0} angle={-25} textAnchor="end" height={60} stroke="#94a3b8" />
                      <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <Tooltip
                        formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, "Total"]}
                        contentStyle={tooltipStyle}
                      />
                      <Bar dataKey="totalKg" radius={[6, 6, 0, 0]}>
                        {categoryBreakdown.map((entry) => (
                          <Cell key={entry.category} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card className="lg:col-span-2">
              <header className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold">Waste collected over time</h3>
                <span className="text-xs text-slate-500">Daily</span>
              </header>
              {daily.length === 0 ? (
                <EmptyChart />
              ) : (
                <div className="h-72">
                  <ResponsiveContainer>
                    <LineChart data={daily}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                      <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <Tooltip
                        formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                        contentStyle={tooltipStyle}
                      />
                      <Legend wrapperStyle={legendStyle} />
                      <Line type="monotone" dataKey="totalKg" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} name="Total" />
                      <Line type="monotone" dataKey="recycledKg" stroke="#0ea5e9" strokeWidth={2} dot={{ r: 3 }} name="Recycled" />
                      <Line type="monotone" dataKey="compostedKg" stroke="#84cc16" strokeWidth={2} dot={{ r: 3 }} name="Composted" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card className="lg:col-span-2">
              <header className="mb-3 flex items-center justify-between">
                <h3 className="text-sm font-semibold">Recycling vs disposal (monthly)</h3>
                <span className="text-xs text-slate-500">Comparison</span>
              </header>
              {recyclingVs.length === 0 ? (
                <EmptyChart />
              ) : (
                <div className="h-72">
                  <ResponsiveContainer>
                    <BarChart data={recyclingVs}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <Tooltip
                        formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                        contentStyle={tooltipStyle}
                      />
                      <Legend wrapperStyle={legendStyle} />
                      <Bar dataKey="Recycled" stackId="a" fill="#0ea5e9" />
                      <Bar dataKey="Composted" stackId="a" fill="#16a34a" />
                      <Bar dataKey="Disposed" stackId="a" fill="#dc2626" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
          </section>

          <section className="grid gap-4 lg:grid-cols-3">
            <Card>
              <h3 className="text-sm font-semibold">Period breakdowns</h3>
              <ul className="mt-3 space-y-2 text-sm">
                <BreakdownRow label="Total records" value={String(summary.recordCount)} />
                <BreakdownRow
                  label="Daily average"
                  value={`${(summary.totalKg / Math.max(uniqueDays(filtered), 1)).toFixed(1)} kg/day`}
                />
                <BreakdownRow
                  label="Weekly average"
                  value={`${(summary.totalKg / Math.max(uniqueWeeks(filtered), 1)).toFixed(1)} kg/wk`}
                />
                <BreakdownRow
                  label="Monthly average"
                  value={`${(summary.totalKg / Math.max(uniqueMonths(filtered), 1)).toFixed(1)} kg/mo`}
                />
                <BreakdownRow
                  label="Yearly average"
                  value={`${(summary.totalKg / Math.max(uniqueYears(filtered), 1)).toFixed(1)} kg/yr`}
                />
              </ul>
            </Card>
            <Card className="lg:col-span-2">
              <h3 className="text-sm font-semibold">Recommendations</h3>
              <ul className="mt-3 space-y-3">
                {recs.slice(0, 3).map((r) => (
                  <li
                    key={r.id}
                    className={`rounded-xl border p-3 text-sm ${
                      r.severity === "warning"
                        ? "border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-100"
                        : r.severity === "success"
                          ? "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-100"
                          : "border-sky-300 bg-sky-50 text-sky-900 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-100"
                    }`}
                  >
                    <p className="font-semibold">{r.title}</p>
                    <p className="mt-1 text-xs leading-relaxed">{r.message}</p>
                  </li>
                ))}
              </ul>
            </Card>
          </section>

          <Card>
            <h3 className="text-sm font-semibold">Category reference</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Ten categories are supported. Each record belongs to exactly one category; recycling and
              disposal are tracked separately through the status field.
            </p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {WASTE_CATEGORIES.map((c) => (
                <div
                  key={c.key}
                  className="flex items-start gap-3 rounded-xl border border-slate-200 p-3 text-sm dark:border-slate-800"
                >
                  <span
                    className="mt-1 h-3 w-3 flex-shrink-0 rounded-full"
                    style={{ background: c.color }}
                    aria-hidden
                  />
                  <div>
                    <p className="font-semibold">{c.label}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{c.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </>
      )}

      <RecordForm open={openForm} onClose={() => setOpenForm(false)} />
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="flex h-48 flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 text-center text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
      <p>No data in the selected period.</p>
      <p className="text-xs">Adjust filters or add new records.</p>
    </div>
  );
}

function BreakdownRow({ label, value }: { label: string; value: string }) {
  return (
    <li className="flex items-center justify-between border-b border-slate-100 pb-2 last:border-none dark:border-slate-800">
      <span className="text-slate-500 dark:text-slate-400">{label}</span>
      <span className="font-medium">{value}</span>
    </li>
  );
}

function uniqueDays(records: { collectionDate: string }[]) {
  return new Set(records.map((r) => r.collectionDate)).size || 1;
}
function uniqueWeeks(records: { collectionDate: string }[]) {
  const set = new Set<string>();
  for (const r of records) {
    const d = new Date(r.collectionDate);
    const wk = `${d.getUTCFullYear()}-W${Math.ceil(((d.getTime() - Date.UTC(d.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7)}`;
    set.add(wk);
  }
  return set.size || 1;
}
function uniqueMonths(records: { collectionDate: string }[]) {
  const set = new Set(records.map((r) => r.collectionDate.slice(0, 7)));
  return set.size || 1;
}
function uniqueYears(records: { collectionDate: string }[]) {
  const set = new Set(records.map((r) => r.collectionDate.slice(0, 4)));
  return set.size || 1;
}

const tooltipStyle = {
  background: "rgba(15,23,42,0.9)",
  border: "1px solid rgba(148,163,184,0.2)",
  borderRadius: "8px",
  color: "#e2e8f0",
  fontSize: "12px",
};
const legendStyle = { fontSize: "12px", color: "#64748b" };