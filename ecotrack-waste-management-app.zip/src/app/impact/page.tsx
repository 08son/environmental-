"use client";

import { useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Leaf, Recycle, Sprout, Target, Trash2 } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card, StatCard } from "@/components/ConfirmDialog";
import { DateRangeFilter, type DateRangeValue } from "@/components/DateRangeFilter";
import {
  byMonth,
  estimateCarbonAvoided,
  isInDateRange,
  summarise,
} from "@/lib/calculations";

export default function ImpactPage() {
  const { records, settings } = useDataStore();
  const [range, setRange] = useState<DateRangeValue>({ start: null, end: null });

  const filtered = useMemo(
    () => records.filter((r) => isInDateRange(r.collectionDate, range.start, range.end)),
    [records, range],
  );

  const summary = useMemo(() => summarise(filtered), [filtered]);
  const monthly = useMemo(() => byMonth(filtered), [filtered]);

  const carbon = settings
    ? estimateCarbonAvoided(filtered, settings)
    : 0;
  const showEmissions = settings?.showEmissions ?? false;

  const trend = monthly.map((m) => ({
    month: m.label,
    Recycled: m.recycledKg,
    Composted: m.compostedKg,
    Diverted: m.recycledKg + m.compostedKg,
  }));

  const reductionGoal = 50; // kg, illustrative monthly goal
  const diversionGoal = 60; // % diversion goal

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Environmental Impact
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Impact & trends</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Track diversion, monthly trends, and progress toward reduction goals.
          </p>
        </div>
        <DateRangeFilter value={range} onChange={setRange} />
      </div>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Total waste"
          value={summary.totalKg.toFixed(1)}
          unit="kg"
          icon={<Trash2 className="h-5 w-5" />}
          color="emerald"
        />
        <StatCard
          label="Recycled"
          value={summary.recycledKg.toFixed(1)}
          unit="kg"
          icon={<Recycle className="h-5 w-5" />}
          color="sky"
        />
        <StatCard
          label="Composted"
          value={summary.compostedKg.toFixed(1)}
          unit="kg"
          icon={<Sprout className="h-5 w-5" />}
          color="emerald"
        />
        <StatCard
          label="Diverted from disposal"
          value={summary.divertedKg.toFixed(1)}
          unit="kg"
          icon={<Leaf className="h-5 w-5" />}
          color="violet"
          trend={`${summary.diversionRate.toFixed(1)}% diversion rate`}
        />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <Card>
          <h3 className="text-sm font-semibold">Diversion goal</h3>
          <p className="text-xs text-slate-500">Target {diversionGoal}% diversion from landfill</p>
          <div className="mt-3">
            <ProgressBar value={summary.diversionRate} target={diversionGoal} max={100} />
            <p className="mt-2 text-xs text-slate-500">
              Current diversion: <strong>{summary.diversionRate.toFixed(1)}%</strong> · Goal:{" "}
              <strong>{diversionGoal}%</strong>
            </p>
          </div>
        </Card>
        <Card>
          <h3 className="text-sm font-semibold">Monthly reduction goal</h3>
          <p className="text-xs text-slate-500">
            Try to keep monthly average below <strong>{reductionGoal} kg</strong>
          </p>
          <div className="mt-3">
            <ProgressBar
              value={Math.min(100, (summary.totalKg / Math.max(monthly.length, 1) / reductionGoal) * 100)}
              target={100}
              max={120}
              invert
            />
            <p className="mt-2 text-xs text-slate-500">
              Monthly avg: <strong>
                {(summary.totalKg / Math.max(monthly.length, 1)).toFixed(1)} kg
              </strong>{" "}
              · Goal: <strong>{reductionGoal} kg</strong>
            </p>
          </div>
        </Card>
        <Card>
          <h3 className="text-sm font-semibold">Carbon estimate (demo)</h3>
          {showEmissions ? (
            <>
              <p className="mt-2 text-3xl font-bold text-emerald-600 dark:text-emerald-300">
                {carbon.toFixed(1)} <span className="text-sm font-medium">kgCO₂e</span>
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Demonstration estimate based on emission factors you can edit on the Settings page.
                Default factors (kgCO₂e per kg): Plastic 2.5, Paper 0.95, Organic 0.5, Metal 4.0, Glass 0.8.
              </p>
            </>
          ) : (
            <p className="mt-2 text-sm text-slate-500">
              Carbon estimate is disabled. Enable it on the Settings page to see a demonstration estimate.
            </p>
          )}
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="text-sm font-semibold">Monthly diversion trend</h3>
          {trend.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data in this period.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <AreaChart data={trend}>
                  <defs>
                    <linearGradient id="d-grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#16a34a" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Legend wrapperStyle={legendStyle} />
                  <Area type="monotone" dataKey="Diverted" stroke="#16a34a" fill="url(#d-grad)" />
                  <Area type="monotone" dataKey="Recycled" stroke="#0ea5e9" fillOpacity={0} />
                  <Area type="monotone" dataKey="Composted" stroke="#84cc16" fillOpacity={0} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card>
          <h3 className="text-sm font-semibold">Recycled vs composted</h3>
          {trend.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data in this period.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Legend wrapperStyle={legendStyle} />
                  <Bar dataKey="Recycled" fill="#0ea5e9" />
                  <Bar dataKey="Composted" fill="#16a34a" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      </section>

      <Card>
        <h3 className="text-sm font-semibold">Assumptions and disclaimer</h3>
        <ul className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
          <li>
            The carbon figure is a demonstration estimate using editable emission factors. It does not
            replace an audited life-cycle assessment.
          </li>
          <li>
            Diversion rate counts each kilogram at most once: status Recycled, Composted, In process or
            Donation.
          </li>
          <li>
            Adjust the goals to match your organisation's policies and review the formulas on the
            Recycling page for full transparency.
          </li>
        </ul>
      </Card>
    </div>
  );
}

function ProgressBar({
  value,
  target,
  max,
  invert,
}: {
  value: number;
  target: number;
  max: number;
  invert?: boolean;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const colour = invert
    ? pct <= 100
      ? "bg-emerald-500"
      : "bg-rose-500"
    : pct >= target
      ? "bg-emerald-500"
      : "bg-amber-500";
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
      <div className={`h-full ${colour}`} style={{ width: `${pct}%` }} />
    </div>
  );
}

const tooltipStyle = {
  background: "rgba(15,23,42,0.9)",
  border: "1px solid rgba(148,163,184,0.2)",
  borderRadius: "8px",
  color: "#e2e8f0",
  fontSize: "12px",
};
const legendStyle = { fontSize: "12px", color: "#64748b" };