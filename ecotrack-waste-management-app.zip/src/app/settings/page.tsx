"use client";

import { useEffect, useState } from "react";
import { Loader2, Moon, Save, Sun } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card } from "@/components/ConfirmDialog";
import { useTheme } from "@/components/ThemeProvider";

interface DraftSettings {
  emissionFactorPlastic: string;
  emissionFactorPaper: string;
  emissionFactorOrganic: string;
  emissionFactorMetal: string;
  emissionFactorGlass: string;
  showEmissions: boolean;
  darkMode: boolean;
}

export default function SettingsPage() {
  const { settings, saveSettings } = useDataStore();
  const { darkMode, setDarkMode } = useTheme();
  const [draft, setDraft] = useState<DraftSettings | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setDraft({
        emissionFactorPlastic: String(settings.emissionFactorPlastic),
        emissionFactorPaper: String(settings.emissionFactorPaper),
        emissionFactorOrganic: String(settings.emissionFactorOrganic),
        emissionFactorMetal: String(settings.emissionFactorMetal),
        emissionFactorGlass: String(settings.emissionFactorGlass),
        showEmissions: settings.showEmissions,
        darkMode: darkMode,
      });
    }
  }, [settings, darkMode]);

  if (!draft) {
    return (
      <Card>
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading settings…
        </div>
      </Card>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const numOrNull = (s: string) => {
      const v = Number(s);
      return Number.isFinite(v) && v >= 0 ? v.toFixed(5) : null;
    };
    await saveSettings({
      emissionFactorPlastic: Number(draft.emissionFactorPlastic),
      emissionFactorPaper: Number(draft.emissionFactorPaper),
      emissionFactorOrganic: Number(draft.emissionFactorOrganic),
      emissionFactorMetal: Number(draft.emissionFactorMetal),
      emissionFactorGlass: Number(draft.emissionFactorGlass),
      showEmissions: draft.showEmissions,
      darkMode: draft.darkMode,
    });
    // ensure sync between provider and persisted flag
    setDarkMode(draft.darkMode);
    setSaving(false);
    // touch local vars to avoid lint warning
    void numOrNull;
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
          Settings
        </p>
        <h2 className="text-2xl font-bold tracking-tight">Preferences & emission factors</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Emission factors are illustrative defaults for the carbon estimate demonstration. Adjust
          them to suit your context.
        </p>
      </div>

      <form onSubmit={submit} className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h3 className="text-sm font-semibold">Appearance</h3>
          <div className="mt-3 space-y-3">
            <label className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800">
              <span className="inline-flex items-center gap-2">
                {draft.darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                Dark theme
              </span>
              <input
                type="checkbox"
                checked={draft.darkMode}
                onChange={(e) => setDraft({ ...draft, darkMode: e.target.checked })}
                className="h-4 w-4 accent-emerald-600"
              />
            </label>
            <label className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800">
              <span>Show carbon estimate (demo)</span>
              <input
                type="checkbox"
                checked={draft.showEmissions}
                onChange={(e) => setDraft({ ...draft, showEmissions: e.target.checked })}
                className="h-4 w-4 accent-emerald-600"
              />
            </label>
          </div>
        </Card>

        <Card>
          <h3 className="text-sm font-semibold">Emission factors</h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Unit: kgCO₂e per kilogram of material diverted from disposal. These are demonstration
            factors that you can edit.
          </p>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <NumberField
              label="Plastic"
              value={draft.emissionFactorPlastic}
              onChange={(v) => setDraft({ ...draft, emissionFactorPlastic: v })}
            />
            <NumberField
              label="Paper"
              value={draft.emissionFactorPaper}
              onChange={(v) => setDraft({ ...draft, emissionFactorPaper: v })}
            />
            <NumberField
              label="Organic"
              value={draft.emissionFactorOrganic}
              onChange={(v) => setDraft({ ...draft, emissionFactorOrganic: v })}
            />
            <NumberField
              label="Metal"
              value={draft.emissionFactorMetal}
              onChange={(v) => setDraft({ ...draft, emissionFactorMetal: v })}
            />
            <NumberField
              label="Glass"
              value={draft.emissionFactorGlass}
              onChange={(v) => setDraft({ ...draft, emissionFactorGlass: v })}
            />
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Defaults: Plastic 2.5, Paper 0.95, Organic 0.5, Metal 4.0, Glass 0.8 kgCO₂e/kg. The
              source, unit, and assumptions are stated above.
            </p>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-60"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save settings
            </button>
          </div>
        </Card>
      </form>
    </div>
  );
}

function NumberField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label>
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label} (kgCO₂e/kg)
      </span>
      <input
        type="number"
        step="0.01"
        min="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
      />
    </label>
  );
}