"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CheckCircle2, Clock, Recycle, Sprout, Trash2, XCircle } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card, StatCard } from "@/components/ConfirmDialog";
import { DateRangeFilter, type DateRangeValue } from "@/components/DateRangeFilter";
import {
  byCategory,
  byMonth,
  isInDateRange,
  summarise,
} from "@/lib/calculations";
import { RECYCLABLE_CATEGORIES } from "@/lib/categories";

export default function RecyclingPage() {
  const { records, loading } = useDataStore();
  const [range, setRange] = useState<DateRangeValue>({ start: null, end: null });

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
  }, []);

  const filtered = useMemo(
    () => records.filter((r) => isInDateRange(r.collectionDate, range.start, range.end)),
    [records, range],
  );

  const summary = useMemo(() => summarise(filtered), [filtered]);
  const cats = useMemo(() => byCategory(filtered), [filtered]);
  const months = useMemo(() => byMonth(filtered), [filtered]);

  const trends = months.map((m) => ({
    month: m.label,
    Recycled: m.recycledKg,
    Composted: m.compostedKg,
  }));

  const recyclableCats = cats.filter((c) => RECYCLABLE_CATEGORIES.includes(c.category));
  const topCategories = [...cats].sort((a, b) => b.totalKg - a.totalKg).slice(0, 5);

  const statusBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of filtered) {
      const w = Number(r.weightKg) || 0;
      map.set(r.status, (map.get(r.status) ?? 0) + w);
    }
    return Array.from(map.entries()).map(([status, kg]) => ({ status, kg }));
  }, [filtered]);

  const safe = (n: number, d: number) => (d > 0 ? (n / d) * 100 : 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Recycling Monitoring
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Recycling & Composting</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Track recyclable materials, composting, and waste sent to disposal.
          </p>
        </div>
        <DateRangeFilter value={range} onChange={setRange} />
      </div>

      {loading ? (
        <Card>Loading…</Card>
      ) : filtered.length === 0 ? (
        <Card>
          <p className="text-sm text-slate-500">
            No records in this period. Add waste records to see recycling analytics.
          </p>
        </Card>
      ) : (
        <>
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Recycled"
              value={summary.recycledKg.toFixed(1)}
              unit="kg"
              icon={<CheckCircle2 className="h-5 w-5" />}
              color="emerald"
              trend={`${summary.recyclingRate.toFixed(1)}% recycling rate`}
            />
            <StatCard
              label="Composted"
              value={summary.compostedKg.toFixed(1)}
              unit="kg"
              icon={<Sprout className="h-5 w-5" />}
              color="emerald"
              trend={`${summary.compostingRate.toFixed(1)}% composting rate`}
            />
            <StatCard
              label="Diverted from disposal"
              value={summary.divertedKg.toFixed(1)}
              unit="kg"
              icon={<Recycle className="h-5 w-5" />}
              color="violet"
              trend={`${summary.diversionRate.toFixed(1)}% diversion rate`}
            />
            <StatCard
              label="Sent to disposal"
              value={summary.disposedKg.toFixed(1)}
              unit="kg"
              icon={<Trash2 className="h-5 w-5" />}
              color="rose"
              trend={`${safe(summary.disposedKg, summary.totalKg).toFixed(1)}% of total`}
            />
          </section>

          <Card>
            <h3 className="text-sm font-semibold">How the rates are calculated</h3>
            <ul className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
              <li>
                <strong className="text-slate-700 dark:text-slate-200">Recycling rate</strong> = weight
                marked as status <em>Recycled</em> ÷ total weight × 100.
              </li>
              <li>
                <strong className="text-slate-700 dark:text-slate-200">Composting rate</strong> = weight
                marked as status <em>Composted</em> ÷ total weight × 100.
              </li>
              <li>
                <strong className="text-slate-700 dark:text-slate-200">Diversion rate</strong> = weight
                with status <em>Recycled</em>, <em>Composted</em>, <em>In process</em> or <em>Donation</em>{" "}
                ÷ total weight × 100. Each kilogram is counted at most once.
              </li>
            </ul>
          </Card>

          <section className="grid gap-4 lg:grid-cols-2">
            <Card>
              <h3 className="text-sm font-semibold">Recyclable materials by category</h3>
              {recyclableCats.length === 0 ? (
                <p className="mt-2 text-xs text-slate-500">No recyclable categories in this period.</p>
              ) : (
                <div className="mt-3 h-72">
                  <ResponsiveContainer>
                    <BarChart data={recyclableCats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                      <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <Tooltip
                        formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, "Collected"]}
                        contentStyle={tooltipStyle}
                      />
                      <Bar dataKey="totalKg" radius={[6, 6, 0, 0]}>
                        {recyclableCats.map((entry) => (
                          <Cell key={entry.category} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card>
              <h3 className="text-sm font-semibold">Monthly recycling & composting</h3>
              {trends.length === 0 ? (
                <p className="mt-2 text-xs text-slate-500">No monthly trend yet.</p>
              ) : (
                <div className="mt-3 h-72">
                  <ResponsiveContainer>
                    <AreaChart data={trends}>
                      <defs>
                        <linearGradient id="r-grad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.6} />
                          <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="c-grad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#16a34a" stopOpacity={0.6} />
                          <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                      <Tooltip
                        formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                        contentStyle={tooltipStyle}
                      />
                      <Legend wrapperStyle={legendStyle} />
                      <Area type="monotone" dataKey="Recycled" stroke="#0ea5e9" fill="url(#r-grad)" />
                      <Area type="monotone" dataKey="Composted" stroke="#16a34a" fill="url(#c-grad)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>

            <Card className="lg:col-span-2">
              <h3 className="text-sm font-semibold">Categories with the highest waste generation</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Focus your segregation and reduction efforts on these categories first.
              </p>
              <div className="mt-3 grid gap-2 md:grid-cols-2">
                {topCategories.map((c) => (
                  <div
                    key={c.category}
                    className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800"
                  >
                    <span className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full" style={{ background: c.color }} aria-hidden />
                      {c.label}
                    </span>
                    <span className="font-medium">{c.totalKg.toFixed(1)} kg</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="lg:col-span-2">
              <h3 className="text-sm font-semibold">Processing status distribution</h3>
              <div className="mt-3 grid gap-2 sm:grid-cols-2 md:grid-cols-3">
                {statusBreakdown.map((s) => (
                  <div
                    key={s.status}
                    className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800"
                  >
                    <span className="flex items-center gap-2 capitalize">
                      {statusIcon(s.status)}
                      {s.status.replace("_", " ")}
                    </span>
                    <span className="font-medium">{s.kg.toFixed(1)} kg</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="lg:col-span-2">
              <h3 className="text-sm font-semibold">Suggested waste-reduction practices</h3>
              <ul className="mt-2 grid gap-2 text-sm md:grid-cols-2">
                <Tip text="Set up separate bins for wet, dry, and hazardous waste at source." />
                <Tip text="Run a composting pit or bin for wet/organic waste to produce manure on-site." />
                <Tip text="Partner with authorised recyclers for plastic, paper, metal, glass, and e-waste." />
                <Tip text="Audit disposal bins monthly to identify contamination and reduce landfill load." />
                <Tip text="Replace single-use plastics with reusables in canteens and events." />
                <Tip text="Encourage double-sided printing and digital documentation to reduce paper waste." />
              </ul>
            </Card>
          </section>
        </>
      )}
    </div>
  );
}

function Tip({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-2 rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800">
      <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-600" aria-hidden />
      <span>{text}</span>
    </li>
  );
}

function statusIcon(status: string) {
  const map: Record<string, React.ReactNode> = {
    recycled: <Recycle className="h-4 w-4 text-emerald-600" />,
    composted: <Sprout className="h-4 w-4 text-emerald-600" />,
    disposed: <Trash2 className="h-4 w-4 text-rose-600" />,
    awaiting: <Clock className="h-4 w-4 text-amber-600" />,
    in_process: <Clock className="h-4 w-4 text-amber-600" />,
    collected: <CheckCircle2 className="h-4 w-4 text-sky-600" />,
  };
  return map[status] ?? <XCircle className="h-4 w-4 text-slate-500" />;
}

const tooltipStyle = {
  background: "rgba(15,23,42,0.9)",
  border: "1px solid rgba(148,163,184,0.2)",
  borderRadius: "8px",
  color: "#e2e8f0",
  fontSize: "12px",
};
const legendStyle = { fontSize: "12px", color: "#64748b" };