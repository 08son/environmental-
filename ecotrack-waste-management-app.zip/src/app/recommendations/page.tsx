"use client";

import { useMemo } from "react";
import { Lightbulb, ShieldAlert, Sparkles } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card } from "@/components/ConfirmDialog";
import { generateRecommendations } from "@/lib/calculations";

const TONE = {
  warning: "border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-100",
  success:
    "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-500/40 dark:bg-emerald-500/10 dark:text-emerald-100",
  info: "border-sky-300 bg-sky-50 text-sky-900 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-100",
};

const ICON = {
  warning: ShieldAlert,
  success: Sparkles,
  info: Lightbulb,
};

export default function RecommendationsPage() {
  const { records, goals } = useDataStore();
  const recs = useMemo(() => generateRecommendations(records, goals), [records, goals]);

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
          Smart Recommendations
        </p>
        <h2 className="text-2xl font-bold tracking-tight">Rule-based insights from your records</h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          EcoTrack analyses your data with simple rules — recommendations update automatically when
          records or goals change. They are guidance, not AI-generated analysis.
        </p>
      </div>

      <Card>
        <h3 className="text-sm font-semibold">How recommendations are generated</h3>
        <ul className="mt-2 space-y-1 text-xs text-slate-500 dark:text-slate-400">
          <li>• High share of plastic (&gt; 30%): suggest reusables and dedicated collection.</li>
          <li>• High share of organic (&gt; 25%) and low composting rate (&lt; 25%): suggest segregated bins and composting.</li>
          <li>• High share of paper (&gt; 15%): suggest double-sided printing and pulping.</li>
          <li>• Diversion rate falls &gt; 5% between two consecutive months: suggest auditing bins.</li>
          <li>• Active goals: report progress, remaining kg, and whether the period has ended.</li>
        </ul>
      </Card>

      <section className="grid gap-4 md:grid-cols-2">
        {recs.map((r) => {
          const Icon = ICON[r.severity];
          return (
            <div key={r.id} className={`rounded-2xl border p-5 shadow-sm ${TONE[r.severity]}`}>
              <div className="flex items-start gap-3">
                <Icon className="h-5 w-5" aria-hidden />
                <div>
                  <h3 className="text-base font-semibold">{r.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed">{r.message}</p>
                </div>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}