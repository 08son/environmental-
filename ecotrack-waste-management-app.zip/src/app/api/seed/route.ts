import { NextResponse } from "next/server";
import { db } from "@/db";
import { wasteRecords } from "@/db/schema";

export const dynamic = "force-dynamic";

// A small set of clearly-marked sample records for first-time users.
function isoDate(daysAgo: number) {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().slice(0, 10);
}

const sample = [
  { category: "wet_organic", description: "Kitchen food scraps", weightKg: 4.5, daysAgo: 1, location: "Canteen", processingMethod: "composting", status: "composted", notes: "From morning prep" },
  { category: "plastic", description: "PET bottles", weightKg: 2.3, daysAgo: 1, location: "Hostel Block A", processingMethod: "recycling", status: "recycled", notes: "" },
  { category: "paper", description: "Used A4 sheets", weightKg: 6.1, daysAgo: 2, location: "Admin Office", processingMethod: "recycling", status: "recycled", notes: "Confidential paper shredded" },
  { category: "glass", description: "Borosilicate bottles", weightKg: 1.8, daysAgo: 3, location: "Chemistry Lab", processingMethod: "recycling", status: "in_process", notes: "Rinsed and sorted" },
  { category: "ewaste", description: "Old cables and adapters", weightKg: 0.6, daysAgo: 4, location: "IT Department", processingMethod: "other", status: "awaiting", notes: "Awaiting authorised pickup" },
  { category: "metal", description: "Aluminium cans", weightKg: 0.9, daysAgo: 5, location: "Cafeteria", processingMethod: "recycling", status: "recycled", notes: "" },
  { category: "wet_organic", description: "Garden leaves", weightKg: 7.5, daysAgo: 6, location: "Garden", processingMethod: "composting", status: "composted", notes: "Compost pit" },
  { category: "plastic", description: "Food wrappers", weightKg: 1.2, daysAgo: 7, location: "Canteen", processingMethod: "incineration", status: "disposed", notes: "Mixed low-value plastic" },
  { category: "dry", description: "Dust and sweepings", weightKg: 1.5, daysAgo: 8, location: "Classrooms", processingMethod: "landfill", status: "disposed", notes: "" },
  { category: "hazardous", description: "Used lab chemicals", weightKg: 0.3, daysAgo: 9, location: "Chemistry Lab", processingMethod: "storage", status: "awaiting", notes: "Stored in labelled containers" },
  { category: "recyclable", description: "Mixed dry recyclables", weightKg: 3.2, daysAgo: 10, location: "Library", processingMethod: "recycling", status: "collected", notes: "" },
  { category: "other", description: "Broken ceramic mugs", weightKg: 0.7, daysAgo: 12, location: "Cafeteria", processingMethod: "landfill", status: "disposed", notes: "" },
  { category: "wet_organic", description: "Fruit peel", weightKg: 2.4, daysAgo: 13, location: "Canteen", processingMethod: "composting", status: "composted", notes: "" },
  { category: "paper", description: "Cardboard boxes", weightKg: 5.0, daysAgo: 15, location: "Stores", processingMethod: "recycling", status: "recycled", notes: "" },
  { category: "plastic", description: "Single-use cups", weightKg: 1.1, daysAgo: 18, location: "Events Hall", processingMethod: "recycling", status: "recycled", notes: "Post-event collection" },
];

export async function POST() {
  try {
    // Only seed if the table is empty.
    const existing = await db.select().from(wasteRecords);
    if (existing.length > 0) {
      return NextResponse.json({
        ok: true,
        seeded: 0,
        message: "Records already exist; skipping seed.",
      });
    }
    let count = 0;
    for (const s of sample) {
      await db.insert(wasteRecords).values({
        category: s.category as never,
        description: s.description,
        weightKg: s.weightKg.toFixed(2),
        collectionDate: isoDate(s.daysAgo),
        location: s.location,
        processingMethod: s.processingMethod as never,
        status: s.status as never,
        notes: s.notes || null,
      });
      count += 1;
    }
    return NextResponse.json({ ok: true, seeded: count });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}