import { NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const DEFAULT_USER = "default";

export async function GET() {
  try {
    let row = (
      await db.select().from(settings).where(eq(settings.userId, DEFAULT_USER))
    )[0];
    if (!row) {
      const [inserted] = await db
        .insert(settings)
        .values({ userId: DEFAULT_USER })
        .returning();
      row = inserted;
    }
    return NextResponse.json({
      settings: {
        emissionFactorPlastic: Number(row.emissionFactorPlastic),
        emissionFactorPaper: Number(row.emissionFactorPaper),
        emissionFactorOrganic: Number(row.emissionFactorOrganic),
        emissionFactorMetal: Number(row.emissionFactorMetal),
        emissionFactorGlass: Number(row.emissionFactorGlass),
        showEmissions: !!row.showEmissions,
        darkMode: !!row.darkMode,
      },
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const key of [
      "emissionFactorPlastic",
      "emissionFactorPaper",
      "emissionFactorOrganic",
      "emissionFactorMetal",
      "emissionFactorGlass",
    ]) {
      if (body[key] != null) {
        const v = Number(body[key]);
        if (!Number.isFinite(v) || v < 0) {
          return NextResponse.json(
            { error: `${key} must be a non-negative number` },
            { status: 400 },
          );
        }
        patch[key] = v.toFixed(4);
      }
    }
    if (body.showEmissions != null) {
      patch.showEmissions = body.showEmissions ? 1 : 0;
    }
    if (body.darkMode != null) {
      patch.darkMode = body.darkMode ? 1 : 0;
    }
    const existing = (
      await db.select().from(settings).where(eq(settings.userId, DEFAULT_USER))
    )[0];
    if (!existing) {
      const [inserted] = await db
        .insert(settings)
        .values({ userId: DEFAULT_USER, ...patch })
        .returning();
      return NextResponse.json({ settings: inserted });
    }
    const [updated] = await db
      .update(settings)
      .set(patch)
      .where(eq(settings.userId, DEFAULT_USER))
      .returning();
    return NextResponse.json({ settings: updated });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}