import { NextResponse } from "next/server";
import { db } from "@/db";
import { wasteRecords } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const {
      category,
      description,
      weightKg,
      collectionDate,
      location,
      processingMethod,
      status,
      notes,
    } = body ?? {};
    if (
      !category ||
      !description ||
      weightKg == null ||
      !collectionDate ||
      !location ||
      !processingMethod ||
      !status
    ) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }
    const weight = Number(weightKg);
    if (!Number.isFinite(weight) || weight <= 0) {
      return NextResponse.json(
        { error: "Weight must be a positive number" },
        { status: 400 },
      );
    }
    const dateObj = new Date(collectionDate);
    if (Number.isNaN(dateObj.getTime())) {
      return NextResponse.json(
        { error: "Invalid collection date" },
        { status: 400 },
      );
    }
    const isoDate = collectionDate.length === 10 ? collectionDate : collectionDate.slice(0, 10);
    const [updated] = await db
      .update(wasteRecords)
      .set({
        category,
        description: String(description).trim(),
        weightKg: weight.toFixed(2),
        collectionDate: isoDate,
        location: String(location).trim(),
        processingMethod,
        status,
        notes: notes ? String(notes).trim() : null,
        updatedAt: new Date(),
      })
      .where(eq(wasteRecords.id, Number(id)))
      .returning();
    if (!updated) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({
      record: { ...updated, weightKg: Number(updated.weightKg) },
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}