import { NextResponse } from "next/server";
import { db } from "@/db";
import { wasteRecords } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select()
      .from(wasteRecords)
      .orderBy(desc(wasteRecords.collectionDate), asc(wasteRecords.id));
    const records = rows.map((r) => ({
      ...r,
      weightKg: Number(r.weightKg),
    }));
    return NextResponse.json({ records });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      category,
      description,
      weightKg,
      collectionDate,
      location,
      processingMethod,
      status,
      notes,
    } = body ?? {};
    if (
      !category ||
      !description ||
      weightKg == null ||
      !collectionDate ||
      !location ||
      !processingMethod ||
      !status
    ) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }
    const weight = Number(weightKg);
    if (!Number.isFinite(weight) || weight <= 0) {
      return NextResponse.json(
        { error: "Weight must be a positive number" },
        { status: 400 },
      );
    }
    const dateObj = new Date(collectionDate);
    if (Number.isNaN(dateObj.getTime())) {
      return NextResponse.json(
        { error: "Invalid collection date" },
        { status: 400 },
      );
    }
    const isoDate = collectionDate.length === 10 ? collectionDate : collectionDate.slice(0, 10);
    const [inserted] = await db
      .insert(wasteRecords)
      .values({
        category,
        description: String(description).trim(),
        weightKg: weight.toFixed(2),
        collectionDate: isoDate,
        location: String(location).trim(),
        processingMethod,
        status,
        notes: notes ? String(notes).trim() : null,
      })
      .returning();
    return NextResponse.json({
      record: { ...inserted, weightKg: Number(inserted.weightKg) },
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.delete(wasteRecords).where(eq(wasteRecords.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}