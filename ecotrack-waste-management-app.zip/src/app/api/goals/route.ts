import { NextResponse } from "next/server";
import { db } from "@/db";
import { goals } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(goals).orderBy(asc(goals.id));
    return NextResponse.json({
      goals: rows.map((g) => ({ ...g, targetKg: Number(g.targetKg) })),
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { type, title, targetKg, periodStart, periodEnd } = body ?? {};
    if (!type || !title || targetKg == null || !periodStart || !periodEnd) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }
    const target = Number(targetKg);
    if (!Number.isFinite(target) || target <= 0) {
      return NextResponse.json(
        { error: "Target must be a positive number" },
        { status: 400 },
      );
    }
    const [inserted] = await db
      .insert(goals)
      .values({
        type,
        title: String(title).trim(),
        targetKg: target.toFixed(2),
        periodStart,
        periodEnd,
      })
      .returning();
    return NextResponse.json({
      goal: { ...inserted, targetKg: Number(inserted.targetKg) },
    });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await db.delete(goals).where(eq(goals.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json(
      { error: (err as Error).message },
      { status: 500 },
    );
  }
}