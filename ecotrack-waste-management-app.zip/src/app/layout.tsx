import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/AppShell";
import { DataStoreProvider } from "@/components/useDataStore";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Toaster } from "@/components/Toaster";

export const metadata: Metadata = {
  title: "EcoTrack – Smart Waste Management",
  description:
    "Track waste generation, monitor recycling activities, and improve waste management practices with EcoTrack.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-slate-50 text-slate-900 antialiased">
        <ThemeProvider>
          <DataStoreProvider>
            <AppShell>
              {children}
              <Toaster />
            </AppShell>
          </DataStoreProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}