"use client";

import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Download, FileDown, Printer } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card } from "@/components/ConfirmDialog";
import { DateRangeFilter, formatDate, type DateRangeValue } from "@/components/DateRangeFilter";
import {
  byCategory,
  byDay,
  byMonth,
  exportCsv,
  downloadCsv,
  isInDateRange,
  summarise,
} from "@/lib/calculations";

type ReportKey = "daily" | "weekly" | "monthly" | "yearly" | "category" | "recycling" | "disposal" | "goals";

const REPORT_LABELS: Record<ReportKey, string> = {
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
  yearly: "Yearly",
  category: "Category-wise",
  recycling: "Recycling & Composting",
  disposal: "Disposal",
  goals: "Environmental Goal Progress",
};

export default function ReportsPage() {
  const { records, goals } = useDataStore();
  const [range, setRange] = useState<DateRangeValue>({ start: null, end: null });
  const [active, setActive] = useState<ReportKey>("monthly");

  const filtered = useMemo(
    () => records.filter((r) => isInDateRange(r.collectionDate, range.start, range.end)),
    [records, range],
  );
  const summary = useMemo(() => summarise(filtered), [filtered]);
  const months = useMemo(() => byMonth(filtered), [filtered]);
  const days = useMemo(() => byDay(filtered), [filtered]);
  const cats = useMemo(() => byCategory(filtered), [filtered]);

  const yearly = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of filtered) {
      const yr = r.collectionDate.slice(0, 4);
      map.set(yr, (map.get(yr) ?? 0) + (Number(r.weightKg) || 0));
    }
    return Array.from(map.entries()).map(([year, totalKg]) => ({ year, totalKg }));
  }, [filtered]);

  const weekly = useMemo(() => {
    const map = new Map<string, number>();
    for (const r of filtered) {
      const d = new Date(r.collectionDate);
      const onejan = new Date(d.getUTCFullYear(), 0, 1);
      const wk = Math.ceil(
        ((d.getTime() - onejan.getTime()) / 86400000 + onejan.getUTCDay() + 1) / 7,
      );
      const key = `${d.getUTCFullYear()}-W${wk}`;
      map.set(key, (map.get(key) ?? 0) + (Number(r.weightKg) || 0));
    }
    return Array.from(map.entries()).map(([week, totalKg]) => ({ week, totalKg }));
  }, [filtered]);

  const recyclingRows = useMemo(() => {
    return months.map((m) => ({
      month: m.label,
      Recycled: m.recycledKg,
      Composted: m.compostedKg,
    }));
  }, [months]);

  const disposalRows = useMemo(() => {
    return months.map((m) => ({
      month: m.label,
      Disposed: m.disposedKg,
    }));
  }, [months]);

  const goalRows = useMemo(() => {
    return goals.map((g) => {
      const period = records.filter(
        (r) => r.collectionDate >= g.periodStart && r.collectionDate <= g.periodEnd,
      );
      const total = period.reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
      return { title: g.title, type: g.type, targetKg: Number(g.targetKg), achieved: total, period: `${g.periodStart} → ${g.periodEnd}` };
    });
  }, [goals, records]);

  const exportActive = () => {
    let csv = "";
    let filename = `ecotrack-${active}-report-${new Date().toISOString().slice(0, 10)}.csv`;
    if (active === "daily") csv = exportCsv(filtered);
    else if (active === "weekly") {
      csv =
        "Week,Total kg\n" +
        weekly.map((w) => `${w.week},${w.totalKg.toFixed(2)}`).join("\n");
    } else if (active === "monthly") {
      csv =
        "Month,Total kg,Recycled kg,Composted kg,Disposed kg\n" +
        months
          .map((m) =>
            `${m.label},${m.totalKg.toFixed(2)},${m.recycledKg.toFixed(2)},${m.compostedKg.toFixed(2)},${m.disposedKg.toFixed(2)}`,
          )
          .join("\n");
    } else if (active === "yearly") {
      csv =
        "Year,Total kg\n" +
        yearly.map((y) => `${y.year},${y.totalKg.toFixed(2)}`).join("\n");
    } else if (active === "category") {
      csv =
        "Category,Total kg,Records,Percent\n" +
        cats
          .map((c) => `${c.label},${c.totalKg.toFixed(2)},${c.count},${c.percent.toFixed(2)}%`)
          .join("\n");
    } else if (active === "recycling") {
      csv =
        "Month,Recycled kg,Composted kg\n" +
        recyclingRows.map((r) => `${r.month},${r.Recycled.toFixed(2)},${r.Composted.toFixed(2)}`).join("\n");
    } else if (active === "disposal") {
      csv =
        "Month,Disposed kg\n" +
        disposalRows.map((d) => `${d.month},${d.Disposed.toFixed(2)}`).join("\n");
    } else if (active === "goals") {
      csv =
        "Title,Type,Target kg,Achieved kg,Period\n" +
        goalRows
          .map((g) => `"${g.title.replace(/"/g, '""')}",${g.type},${g.targetKg.toFixed(2)},${g.achieved.toFixed(2)},${g.period}`)
          .join("\n");
    }
    downloadCsv(filename, csv);
  };

  const printReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6 print:space-y-4">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between print:hidden">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Reports & Analytics
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Reports</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Build daily, weekly, monthly, yearly, and category-wise reports. Export or print.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <DateRangeFilter value={range} onChange={setRange} />
          <button
            type="button"
            onClick={exportActive}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800"
          >
            <Download className="h-4 w-4" /> Export CSV
          </button>
          <button
            type="button"
            onClick={printReport}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
          >
            <Printer className="h-4 w-4" /> Print
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 print:hidden">
        {(Object.keys(REPORT_LABELS) as ReportKey[]).map((k) => (
          <button
            type="button"
            key={k}
            onClick={() => setActive(k)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium ${
              active === k
                ? "bg-emerald-600 text-white"
                : "border border-slate-200 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
            }`}
          >
            {REPORT_LABELS[k]}
          </button>
        ))}
      </div>

      <div className="hidden print:block">
        <h1 className="text-2xl font-bold">EcoTrack – {REPORT_LABELS[active]} Report</h1>
        <p className="text-sm text-slate-600">
          Period: {range.start ? formatDate(range.start) : "Start"} →{" "}
          {range.end ? formatDate(range.end) : "Today"}
        </p>
      </div>

      <Card>
        <h3 className="text-sm font-semibold">Period summary</h3>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 md:grid-cols-4">
          <Stat label="Total waste" value={`${summary.totalKg.toFixed(1)} kg`} />
          <Stat label="Recycled" value={`${summary.recycledKg.toFixed(1)} kg`} />
          <Stat label="Composted" value={`${summary.compostedKg.toFixed(1)} kg`} />
          <Stat label="Disposed" value={`${summary.disposedKg.toFixed(1)} kg`} />
          <Stat label="Diversion rate" value={`${summary.diversionRate.toFixed(1)}%`} />
          <Stat label="Recycling rate" value={`${summary.recyclingRate.toFixed(1)}%`} />
          <Stat label="Composting rate" value={`${summary.compostingRate.toFixed(1)}%`} />
          <Stat label="Records" value={String(summary.recordCount)} />
        </div>
      </Card>

      {active === "daily" && (
        <Card>
          <h3 className="text-sm font-semibold">Daily waste report</h3>
          {days.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={days}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Bar dataKey="totalKg" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "weekly" && (
        <Card>
          <h3 className="text-sm font-semibold">Weekly waste report</h3>
          {weekly.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={weekly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="week" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Bar dataKey="totalKg" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "monthly" && (
        <Card>
          <h3 className="text-sm font-semibold">Monthly waste report</h3>
          {months.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={months}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Legend wrapperStyle={legendStyle} />
                  <Bar dataKey="totalKg" fill="#10b981" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="recycledKg" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="compostedKg" fill="#16a34a" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="disposedKg" fill="#dc2626" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "yearly" && (
        <Card>
          <h3 className="text-sm font-semibold">Yearly waste report</h3>
          {yearly.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={yearly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="year" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Bar dataKey="totalKg" fill="#475569" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "category" && (
        <Card>
          <h3 className="text-sm font-semibold">Category-wise report</h3>
          {cats.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 grid gap-4 md:grid-cols-2">
              <div className="h-72">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie
                      data={cats}
                      dataKey="totalKg"
                      nameKey="label"
                      outerRadius={88}
                      innerRadius={48}
                    >
                      {cats.map((entry) => (
                        <Cell key={entry.category} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                      contentStyle={tooltipStyle}
                    />
                    <Legend wrapperStyle={legendStyle} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div>
                <table className="w-full text-sm">
                  <thead className="text-left text-xs uppercase tracking-wider text-slate-500">
                    <tr>
                      <th className="py-2">Category</th>
                      <th className="py-2">Total kg</th>
                      <th className="py-2">Records</th>
                      <th className="py-2">%</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {cats.map((c) => (
                      <tr key={c.category}>
                        <td className="py-2">
                          <span className="inline-flex items-center gap-2">
                            <span className="h-2 w-2 rounded-full" style={{ background: c.color }} />
                            {c.label}
                          </span>
                        </td>
                        <td className="py-2">{c.totalKg.toFixed(1)}</td>
                        <td className="py-2">{c.count}</td>
                        <td className="py-2">{c.percent.toFixed(1)}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </Card>
      )}

      {active === "recycling" && (
        <Card>
          <h3 className="text-sm font-semibold">Recycling & composting report</h3>
          {recyclingRows.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={recyclingRows}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Legend wrapperStyle={legendStyle} />
                  <Bar dataKey="Recycled" fill="#0ea5e9" />
                  <Bar dataKey="Composted" fill="#16a34a" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "disposal" && (
        <Card>
          <h3 className="text-sm font-semibold">Disposal report</h3>
          {disposalRows.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No data.</p>
          ) : (
            <div className="mt-3 h-72">
              <ResponsiveContainer>
                <BarChart data={disposalRows}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#94a3b8" />
                  <Tooltip
                    formatter={(value) => [`${Number(value ?? 0).toFixed(1)} kg`, ""]}
                    contentStyle={tooltipStyle}
                  />
                  <Bar dataKey="Disposed" fill="#dc2626" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      )}

      {active === "goals" && (
        <Card>
          <h3 className="text-sm font-semibold">Environmental goal progress</h3>
          {goalRows.length === 0 ? (
            <p className="mt-2 text-xs text-slate-500">No goals yet.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wider text-slate-500">
                <tr>
                  <th className="py-2">Title</th>
                  <th className="py-2">Type</th>
                  <th className="py-2">Target kg</th>
                  <th className="py-2">Achieved kg</th>
                  <th className="py-2">Period</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {goalRows.map((g, idx) => (
                  <tr key={idx}>
                    <td className="py-2">{g.title}</td>
                    <td className="py-2 capitalize">{g.type}</td>
                    <td className="py-2">{g.targetKg.toFixed(1)}</td>
                    <td className="py-2">{g.achieved.toFixed(1)}</td>
                    <td className="py-2">{g.period}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      <div className="hidden print:flex items-center gap-2 text-xs text-slate-500">
        <FileDown className="h-4 w-4" /> Generated by EcoTrack.
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 px-3 py-2 text-sm dark:border-slate-800">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="font-semibold">{value}</p>
    </div>
  );
}

const tooltipStyle = {
  background: "rgba(15,23,42,0.9)",
  border: "1px solid rgba(148,163,184,0.2)",
  borderRadius: "8px",
  color: "#e2e8f0",
  fontSize: "12px",
};
const legendStyle = { fontSize: "12px", color: "#64748b" };