"use client";

import { useMemo, useState } from "react";
import { Loader2, Plus, Target, Trash2 } from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card, StatCard } from "@/components/ConfirmDialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { RECYCLED_STATUSES, COMPOSTED_STATUSES, summarise } from "@/lib/calculations";
import type { Goal, WasteRecord } from "@/lib/types";

const GOAL_TYPES: { key: Goal["type"]; label: string; description: string }[] = [
  {
    key: "reduce",
    label: "Reduce total waste",
    description: "Keep total waste generated within the period below a target weight.",
  },
  {
    key: "recycle",
    label: "Recycle a target weight",
    description: "Send at least the target weight of materials for recycling.",
  },
  {
    key: "compost",
    label: "Compost a target weight",
    description: "Send at least the target weight of organic waste for composting.",
  },
];

function inPeriod(r: WasteRecord, g: Goal) {
  return r.collectionDate >= g.periodStart && r.collectionDate <= g.periodEnd;
}

function progressFor(goal: Goal, records: WasteRecord[]) {
  const period = records.filter((r) => inPeriod(r, goal));
  let actual = 0;
  if (goal.type === "reduce") {
    actual = period.reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
  } else if (goal.type === "recycle") {
    actual = period
      .filter((r) => RECYCLED_STATUSES.includes(r.status as never))
      .reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
  } else {
    actual = period
      .filter((r) => COMPOSTED_STATUSES.includes(r.status as never))
      .reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
  }
  const target = Number(goal.targetKg);
  const remaining = Math.max(0, target - actual);
  const pct = target > 0 ? Math.min(100, (actual / target) * 100) : 0;
  const expired = new Date(goal.periodEnd) < new Date();
  return { actual, target, remaining, pct, expired };
}

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function addMonths(iso: string, months: number) {
  const d = new Date(iso);
  d.setMonth(d.getMonth() + months);
  return d.toISOString().slice(0, 10);
}

export default function GoalsPage() {
  const { records, goals, createGoal, deleteGoal } = useDataStore();
  const [open, setOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<Goal | null>(null);
  const [form, setForm] = useState<{
    type: Goal["type"];
    title: string;
    targetKg: string;
    periodStart: string;
    periodEnd: string;
  }>({
    type: "reduce",
    title: "Reduce waste this month",
    targetKg: "20",
    periodStart: todayIso().slice(0, 8) + "01",
    periodEnd: addMonths(todayIso().slice(0, 8) + "01", 1),
  });
  const [submitting, setSubmitting] = useState(false);

  const summary = useMemo(() => summarise(records), [records]);

  const enriched = useMemo(
    () =>
      goals.map((g) => ({
        goal: g,
        progress: progressFor(g, records),
      })),
    [goals, records],
  );

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = Number(form.targetKg);
    if (!form.title.trim() || !Number.isFinite(target) || target <= 0) return;
    if (form.periodEnd < form.periodStart) return;
    setSubmitting(true);
    const created = await createGoal({
      type: form.type,
      title: form.title.trim(),
      targetKg: target,
      periodStart: form.periodStart,
      periodEnd: form.periodEnd,
    });
    setSubmitting(false);
    if (created) {
      setOpen(false);
    }
  };

  const met = enriched.filter((g) => g.progress.pct >= 100).length;
  const inProgress = enriched.filter((g) => g.progress.pct < 100 && !g.progress.expired).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Goals & Challenges
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Set waste-reduction targets</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Goals are tracked from your stored records. Progress is computed only from data within the
            period.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
        >
          <Plus className="h-4 w-4" />
          New goal
        </button>
      </div>

      <section className="grid gap-4 sm:grid-cols-3">
        <StatCard
          label="Active goals"
          value={enriched.length}
          icon={<Target className="h-5 w-5" />}
          color="emerald"
        />
        <StatCard
          label="Goals achieved"
          value={met}
          icon={<Target className="h-5 w-5" />}
          color="emerald"
        />
        <StatCard
          label="In progress"
          value={inProgress}
          icon={<Target className="h-5 w-5" />}
          color="amber"
        />
      </section>

      {enriched.length === 0 ? (
        <Card>
          <div className="flex flex-col items-start gap-3">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No goals yet. Create a goal to track your progress against specific targets.
            </p>
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
            >
              <Plus className="h-4 w-4" /> Create first goal
            </button>
          </div>
        </Card>
      ) : (
        <section className="grid gap-4 md:grid-cols-2">
          {enriched.map(({ goal, progress }) => {
            const tone =
              progress.pct >= 100
                ? "border-emerald-400"
                : progress.expired
                  ? "border-rose-400"
                  : "border-amber-400";
            return (
              <Card key={goal.id} className={`border-l-4 ${tone}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold">{goal.title}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {GOAL_TYPES.find((g) => g.key === goal.type)?.label} ·{" "}
                      {goal.periodStart} → {goal.periodEnd}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPendingDelete(goal)}
                    className="rounded p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10"
                    aria-label="Delete goal"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs">
                    <span>
                      {progress.actual.toFixed(1)} / {progress.target.toFixed(1)} kg
                    </span>
                    <span>{progress.pct.toFixed(0)}%</span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                    <div
                      className={`h-full ${
                        progress.pct >= 100
                          ? "bg-emerald-500"
                          : progress.expired
                            ? "bg-rose-500"
                            : "bg-amber-500"
                      }`}
                      style={{ width: `${progress.pct}%` }}
                    />
                  </div>
                  <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                    {progress.pct >= 100
                      ? "Target achieved 🎉"
                      : progress.expired
                        ? `Period ended. Short by ${progress.remaining.toFixed(1)} kg.`
                        : `${progress.remaining.toFixed(1)} kg remaining.`}
                  </p>
                </div>
              </Card>
            );
          })}
        </section>
      )}

      <Card>
        <h3 className="text-sm font-semibold">Live progress against goals</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Calculated from the {summary.recordCount} records you have entered.
        </p>
      </Card>

      {open && (
        <div className="fixed inset-0 z-40 flex items-end justify-center bg-slate-900/40 px-4 py-8 backdrop-blur-sm md:items-center">
          <form
            onSubmit={submit}
            className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900"
          >
            <h2 className="text-lg font-semibold">Create a goal</h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Pick a target, choose a period, and start tracking progress.
            </p>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <label className="md:col-span-2">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Goal type
                </span>
                <select
                  value={form.type}
                  onChange={(e) =>
                    setForm((cur) => ({ ...cur, type: e.target.value as Goal["type"] }))
                  }
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
                >
                  {GOAL_TYPES.map((g) => (
                    <option key={g.key} value={g.key}>
                      {g.label}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-xs text-slate-500">
                  {GOAL_TYPES.find((g) => g.key === form.type)?.description}
                </p>
              </label>
              <label className="md:col-span-2">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Title
                </span>
                <input
                  type="text"
                  value={form.title}
                  onChange={(e) => setForm((cur) => ({ ...cur, title: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
                />
              </label>
              <label>
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Target weight (kg)
                </span>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={form.targetKg}
                  onChange={(e) => setForm((cur) => ({ ...cur, targetKg: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
                />
              </label>
              <label>
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Period start
                </span>
                <input
                  type="date"
                  value={form.periodStart}
                  onChange={(e) => setForm((cur) => ({ ...cur, periodStart: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
                />
              </label>
              <label className="md:col-span-2">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Period end
                </span>
                <input
                  type="date"
                  value={form.periodEnd}
                  onChange={(e) => setForm((cur) => ({ ...cur, periodEnd: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
                />
              </label>
            </div>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-60"
              >
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Create goal
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={!!pendingDelete}
        title="Delete this goal?"
        description={pendingDelete ? `“${pendingDelete.title}” will be removed.` : undefined}
        destructive
        confirmLabel="Delete"
        onCancel={() => setPendingDelete(null)}
        onConfirm={async () => {
          if (pendingDelete) await deleteGoal(pendingDelete.id);
          setPendingDelete(null);
        }}
      />
    </div>
  );
}