"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowUpDown,
  Download,
  Loader2,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { useDataStore } from "@/components/useDataStore";
import { Card } from "@/components/ConfirmDialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { RecordForm, StatusBadge } from "@/components/Forms";
import {
  DateRangeFilter,
  formatDate,
  useDebouncedValue,
  type DateRangeValue,
} from "@/components/DateRangeFilter";
import {
  PROCESSING_METHODS,
  PROCESSING_STATUSES,
  WASTE_CATEGORIES,
  type ProcessingMethod,
  type ProcessingStatus,
  type WasteCategoryKey,
} from "@/lib/categories";
import { downloadCsv, exportCsv, isInDateRange } from "@/lib/calculations";
import type { WasteRecord } from "@/lib/types";

type SortKey = "date" | "weight" | "category";
type SortDir = "asc" | "desc";

export default function RecordsPage() {
  const { records, loading: dataLoading, deleteRecord, refresh } = useDataStore();
  const [openForm, setOpenForm] = useState(false);
  const [editing, setEditing] = useState<WasteRecord | null>(null);
  const [pendingDelete, setPendingDelete] = useState<WasteRecord | null>(null);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useDebouncedValue(search, 250);
  useEffect(() => setDebouncedSearch(search), [search]);

  const [range, setRange] = useState<DateRangeValue>({ start: null, end: null });
  const [categoryFilter, setCategoryFilter] = useState<WasteCategoryKey | "all">("all");
  const [statusFilter, setStatusFilter] = useState<ProcessingStatus | "all">("all");
  const [methodFilter, setMethodFilter] = useState<ProcessingMethod | "all">("all");
  const [sortKey, setSortKey] = useState<SortKey>("date");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [page, setPage] = useState(1);
  const pageSize = 12;

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const filtered = useMemo(() => {
    const term = debouncedSearch.trim().toLowerCase();
    return records
      .filter((r) => isInDateRange(r.collectionDate, range.start, range.end))
      .filter((r) => (categoryFilter === "all" ? true : r.category === categoryFilter))
      .filter((r) => (statusFilter === "all" ? true : r.status === statusFilter))
      .filter((r) => (methodFilter === "all" ? true : r.processingMethod === methodFilter))
      .filter((r) => {
        if (!term) return true;
        return [
          String(r.id),
          r.description,
          r.location,
          r.category,
          r.processingMethod,
          r.status,
        ]
          .join(" ")
          .toLowerCase()
          .includes(term);
      });
  }, [records, range, categoryFilter, statusFilter, methodFilter, debouncedSearch]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      let cmp = 0;
      if (sortKey === "date") cmp = a.collectionDate.localeCompare(b.collectionDate);
      else if (sortKey === "weight") cmp = a.weightKg - b.weightKg;
      else cmp = a.category.localeCompare(b.category);
      return sortDir === "asc" ? cmp : -cmp;
    });
    return arr;
  }, [filtered, sortKey, sortDir]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const paginated = useMemo(
    () => sorted.slice((page - 1) * pageSize, page * pageSize),
    [sorted, page],
  );

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, range, categoryFilter, statusFilter, methodFilter]);

  const resetFilters = () => {
    setRange({ start: null, end: null });
    setCategoryFilter("all");
    setStatusFilter("all");
    setMethodFilter("all");
    setSearch("");
    setSortKey("date");
    setSortDir("desc");
  };

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const exportFiltered = () => {
    if (sorted.length === 0) return;
    downloadCsv(`ecotrack-records-${new Date().toISOString().slice(0, 10)}.csv`, exportCsv(sorted));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
            Waste Management
          </p>
          <h2 className="text-2xl font-bold tracking-tight">Waste Records</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Add, edit, search, filter and export every collection event.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={exportFiltered}
            disabled={sorted.length === 0}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-medium hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800"
          >
            <Download className="h-4 w-4" /> Export CSV
          </button>
          <button
            type="button"
            onClick={() => {
              setEditing(null);
              setOpenForm(true);
            }}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700"
          >
            <Plus className="h-4 w-4" />
            Add record
          </button>
        </div>
      </div>

      <Card>
        <div className="grid gap-3 md:grid-cols-5">
          <label className="md:col-span-2">
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Search
            </span>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by description, location, category, ID…"
                className="w-full rounded-lg border border-slate-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
              />
            </div>
          </label>
          <label>
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Category
            </span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as never)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="all">All categories</option>
              {WASTE_CATEGORIES.map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Status
            </span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as never)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="all">All statuses</option>
              {PROCESSING_STATUSES.map((s) => (
                <option key={s.key} value={s.key}>
                  {s.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Method
            </span>
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value as never)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-800"
            >
              <option value="all">All methods</option>
              {PROCESSING_METHODS.map((m) => (
                <option key={m.key} value={m.key}>
                  {m.label}
                </option>
              ))}
            </select>
          </label>
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <DateRangeFilter value={range} onChange={setRange} />
          <button
            type="button"
            onClick={resetFilters}
            className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            Clear all filters
          </button>
        </div>
      </Card>

      <Card>
        {dataLoading ? (
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading records…
          </div>
        ) : sorted.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
            <p>No records match your filters.</p>
            <button
              type="button"
              onClick={resetFilters}
              className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-sm dark:divide-slate-800">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  <th className="py-2 pr-2">ID</th>
                  <th className="py-2 pr-2">
                    <button
                      type="button"
                      onClick={() => toggleSort("date")}
                      className="inline-flex items-center gap-1 hover:text-emerald-600"
                    >
                      Date <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="py-2 pr-2">
                    <button
                      type="button"
                      onClick={() => toggleSort("category")}
                      className="inline-flex items-center gap-1 hover:text-emerald-600"
                    >
                      Category <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="py-2 pr-2">Description</th>
                  <th className="py-2 pr-2">
                    <button
                      type="button"
                      onClick={() => toggleSort("weight")}
                      className="inline-flex items-center gap-1 hover:text-emerald-600"
                    >
                      Weight <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="py-2 pr-2">Location</th>
                  <th className="py-2 pr-2">Method</th>
                  <th className="py-2 pr-2">Status</th>
                  <th className="py-2 pr-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paginated.map((r) => {
                  const cat = WASTE_CATEGORIES.find((c) => c.key === r.category);
                  return (
                    <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="py-2 pr-2 font-mono text-xs text-slate-500">#{r.id}</td>
                      <td className="py-2 pr-2 whitespace-nowrap">{formatDate(r.collectionDate)}</td>
                      <td className="py-2 pr-2">
                        <span className="inline-flex items-center gap-2">
                          <span
                            className="h-2 w-2 rounded-full"
                            style={{ background: cat?.color ?? "#64748b" }}
                            aria-hidden
                          />
                          {cat?.label ?? r.category}
                        </span>
                      </td>
                      <td className="py-2 pr-2 max-w-xs truncate" title={r.description}>
                        {r.description}
                      </td>
                      <td className="py-2 pr-2 font-medium">{r.weightKg.toFixed(2)} kg</td>
                      <td className="py-2 pr-2">{r.location}</td>
                      <td className="py-2 pr-2">
                        {PROCESSING_METHODS.find((m) => m.key === r.processingMethod)?.label}
                      </td>
                      <td className="py-2 pr-2">
                        <StatusBadge status={r.status} />
                      </td>
                      <td className="py-2 pr-2 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditing(r);
                              setOpenForm(true);
                            }}
                            className="rounded p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                            aria-label="Edit"
                          >
                            <Pencil className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setPendingDelete(r)}
                            className="rounded p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10"
                            aria-label="Delete"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {sorted.length > pageSize && (
          <div className="mt-3 flex items-center justify-between text-sm">
            <p className="text-slate-500">
              Page {page} of {totalPages} · {sorted.length} records
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                Previous
              </button>
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </Card>

      <RecordForm
        open={openForm}
        editing={editing}
        onClose={() => {
          setOpenForm(false);
          setEditing(null);
        }}
      />

      <ConfirmDialog
        open={!!pendingDelete}
        title="Delete this record?"
        description={
          pendingDelete
            ? `Record #${pendingDelete.id} (${pendingDelete.weightKg.toFixed(2)} kg) will be permanently removed.`
            : undefined
        }
        destructive
        confirmLabel="Delete"
        onCancel={() => setPendingDelete(null)}
        onConfirm={async () => {
          if (pendingDelete) await deleteRecord(pendingDelete.id);
          setPendingDelete(null);
        }}
      />
    </div>
  );
}