"use client";

import { useDataStore } from "@/components/useDataStore";
import { AlertCircle, CheckCircle2, Info, X } from "lucide-react";

export function Toaster() {
  const { toasts, dismissToast } = useDataStore();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-50 flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => {
        const Icon =
          t.type === "success" ? CheckCircle2 : t.type === "error" ? AlertCircle : Info;
        const colour =
          t.type === "success"
            ? "border-emerald-500/40 bg-emerald-50 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-100"
            : t.type === "error"
              ? "border-rose-500/40 bg-rose-50 text-rose-800 dark:bg-rose-500/15 dark:text-rose-100"
              : "border-sky-500/40 bg-sky-50 text-sky-800 dark:bg-sky-500/15 dark:text-sky-100";
        return (
          <div
            key={t.id}
            className={`pointer-events-auto flex w-full max-w-md items-start gap-3 rounded-xl border px-4 py-3 shadow-lg ${colour}`}
            role="status"
          >
            <Icon className="mt-0.5 h-5 w-5 flex-shrink-0" aria-hidden />
            <p className="flex-1 text-sm">{t.message}</p>
            <button
              type="button"
              className="rounded p-1 text-slate-500 hover:bg-white/40 dark:hover:bg-black/20"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}