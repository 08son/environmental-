"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

interface ThemeContextValue {
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  ready: boolean;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [darkMode, setDarkModeState] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    const stored = window.localStorage.getItem("ecotrack-dark");
    if (stored === "1") {
      setDarkModeState(true);
      root.classList.add("dark");
    }
    setReady(true);
  }, []);

  const setDarkMode = useCallback((v: boolean) => {
    setDarkModeState(v);
    const root = document.documentElement;
    if (v) {
      root.classList.add("dark");
      window.localStorage.setItem("ecotrack-dark", "1");
    } else {
      root.classList.remove("dark");
      window.localStorage.setItem("ecotrack-dark", "0");
    }
  }, []);

  const value = useMemo(
    () => ({ darkMode, setDarkMode, ready }),
    [darkMode, setDarkMode, ready],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be inside ThemeProvider");
  return ctx;
}