"use client";

import { useEffect, useMemo, useState } from "react";
import {
  PROCESSING_METHODS,
  PROCESSING_STATUSES,
  STATUS_MAP,
  WASTE_CATEGORIES,
  type ProcessingMethod,
  type ProcessingStatus,
  type WasteCategoryKey,
} from "@/lib/categories";
import type { WasteRecord } from "@/lib/types";
import { useDataStore } from "@/components/useDataStore";
import { Loader2, Save, ShieldAlert, Trash2, X } from "lucide-react";
import { ConfirmDialog } from "@/components/ConfirmDialog";

interface Props {
  open: boolean;
  onClose: () => void;
  editing?: WasteRecord | null;
}

function isoToday() {
  return new Date().toISOString().slice(0, 10);
}

const blank = {
  category: "wet_organic" as WasteCategoryKey,
  description: "",
  weightKg: "",
  collectionDate: isoToday(),
  location: "",
  processingMethod: "composting" as ProcessingMethod,
  status: "collected" as ProcessingStatus,
  notes: "",
};

export function RecordForm({ open, onClose, editing }: Props) {
  const { createRecord, updateRecord } = useDataStore();
  const [form, setForm] = useState({ ...blank });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    if (editing) {
      setForm({
        category: editing.category,
        description: editing.description,
        weightKg: String(editing.weightKg),
        collectionDate: editing.collectionDate,
        location: editing.location,
        processingMethod: editing.processingMethod,
        status: editing.status,
        notes: editing.notes ?? "",
      });
    } else {
      setForm({ ...blank, collectionDate: isoToday() });
    }
    setErrors({});
  }, [editing, open]);

  const selectedCategory = useMemo(
    () => WASTE_CATEGORIES.find((c) => c.key === form.category),
    [form.category],
  );

  if (!open) return null;

  const update = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((cur) => ({ ...cur, [key]: value }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.description.trim()) e.description = "Description is required";
    if (!form.location.trim()) e.location = "Location is required";
    const w = Number(form.weightKg);
    if (!form.weightKg || !Number.isFinite(w) || w <= 0) {
      e.weightKg = "Weight must be a positive number";
    }
    if (!form.collectionDate) e.collectionDate = "Date is required";
    else if (Number.isNaN(new Date(form.collectionDate).getTime()))
      e.collectionDate = "Invalid date";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const payload = {
      category: form.category,
      description: form.description.trim(),
      weightKg: Number(form.weightKg),
      collectionDate: form.collectionDate,
      location: form.location.trim(),
      processingMethod: form.processingMethod,
      status: form.status,
      notes: form.notes.trim() || null,
    };
    const result = editing
      ? await updateRecord(editing.id, payload)
      : await createRecord(payload);
    setSubmitting(false);
    if (result) onClose();
  };

  const reset = () => {
    setForm({ ...blank, collectionDate: isoToday() });
    setErrors({});
  };

  return (
    <>
      <div className="fixed inset-0 z-40 flex items-end justify-center bg-slate-900/40 px-4 py-8 backdrop-blur-sm md:items-center">
        <div className="relative w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-lg font-semibold">
                {editing ? "Edit Waste Record" : "New Waste Collection"}
              </h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {editing
                  ? `Editing record #${editing.id}`
                  : "Log a new waste collection event."}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {selectedCategory?.safetyNote && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-300 bg-rose-50 p-3 text-sm text-rose-700 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-200">
              <ShieldAlert className="mt-0.5 h-4 w-4" aria-hidden />
              <p>{selectedCategory.safetyNote}</p>
            </div>
          )}

          <form onSubmit={submit} className="mt-4 grid gap-4 md:grid-cols-2">
            <Field label="Waste Category" required>
              <select
                value={form.category}
                onChange={(e) => update("category", e.target.value as WasteCategoryKey)}
                className="input"
              >
                {WASTE_CATEGORIES.map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.label}
                  </option>
                ))}
              </select>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {selectedCategory?.description}
              </p>
            </Field>
            <Field label="Waste Description" required error={errors.description}>
              <input
                type="text"
                value={form.description}
                onChange={(e) => update("description", e.target.value)}
                placeholder="e.g. Vegetable peel, plastic bottles"
                className="input"
                maxLength={120}
              />
            </Field>
            <Field label="Weight (kg)" required error={errors.weightKg}>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={form.weightKg}
                onChange={(e) => update("weightKg", e.target.value)}
                placeholder="0.00"
                className="input"
              />
            </Field>
            <Field label="Collection Location" required error={errors.location}>
              <input
                type="text"
                value={form.location}
                onChange={(e) => update("location", e.target.value)}
                placeholder="e.g. Hostel Block A"
                className="input"
              />
            </Field>
            <Field label="Collection Date" required error={errors.collectionDate}>
              <input
                type="date"
                value={form.collectionDate}
                onChange={(e) => update("collectionDate", e.target.value)}
                max={isoToday()}
                className="input"
              />
            </Field>
            <Field label="Processing Method" required>
              <select
                value={form.processingMethod}
                onChange={(e) => update("processingMethod", e.target.value as ProcessingMethod)}
                className="input"
              >
                {PROCESSING_METHODS.map((m) => (
                  <option key={m.key} value={m.key}>
                    {m.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Processing Status" required>
              <select
                value={form.status}
                onChange={(e) => update("status", e.target.value as ProcessingStatus)}
                className="input"
              >
                {PROCESSING_STATUSES.map((s) => (
                  <option key={s.key} value={s.key}>
                    {s.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Notes (optional)">
              <textarea
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                rows={2}
                className="input"
                placeholder="Any extra detail…"
              />
            </Field>

            <div className="md:col-span-2 flex flex-wrap items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <Trash2 className="h-4 w-4" /> Reset
              </button>
              <button
                type="button"
                onClick={onClose}
                className="rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {editing ? "Update Record" : "Save Record"}
              </button>
            </div>
          </form>
        </div>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(226 232 240);
          background: white;
          padding: 0.5rem 0.75rem;
          font-size: 0.875rem;
          outline: none;
        }
        .input:focus {
          border-color: rgb(16 185 129);
          box-shadow: 0 0 0 2px rgb(16 185 129 / 0.15);
        }
        :global(.dark) .input {
          background: rgb(15 23 42);
          border-color: rgb(51 65 85);
          color: rgb(226 232 240);
        }
      `}</style>

      <ConfirmDialog
        open={confirmReset}
        title="Reset the form?"
        description="This will clear all fields."
        destructive
        onConfirm={() => {
          reset();
          setConfirmReset(false);
        }}
        onCancel={() => setConfirmReset(false)}
        confirmLabel="Reset"
      />
    </>
  );
}

function Field({
  label,
  required,
  children,
  error,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
  error?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        {label}
        {required && <span className="ml-1 text-rose-500">*</span>}
      </span>
      {children}
      {error && (
        <span className="mt-1 block text-xs text-rose-600 dark:text-rose-300">{error}</span>
      )}
    </label>
  );
}

export function StatusBadge({ status }: { status: ProcessingStatus }) {
  const info = STATUS_MAP[status];
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium"
      style={{ background: `${info.color}22`, color: info.color }}
    >
      <span
        className="inline-block h-2 w-2 rounded-full"
        style={{ background: info.color }}
        aria-hidden
      />
      {info.label}
    </span>
  );
}