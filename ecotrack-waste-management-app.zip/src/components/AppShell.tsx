"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  BarChart3,
  ClipboardList,
  Goal as GoalIcon,
  Leaf,
  LineChart,
  ListChecks,
  Menu,
  Moon,
  Recycle,
  Sparkles,
  Sun,
  Trash2,
  X,
} from "lucide-react";
import { useTheme } from "./ThemeProvider";

const NAV = [
  { href: "/", label: "Dashboard", icon: BarChart3 },
  { href: "/records", label: "Waste Records", icon: ClipboardList },
  { href: "/recycling", label: "Recycling", icon: Recycle },
  { href: "/impact", label: "Environmental Impact", icon: LineChart },
  { href: "/goals", label: "Goals & Challenges", icon: GoalIcon },
  { href: "/recommendations", label: "Smart Tips", icon: Sparkles },
  { href: "/reports", label: "Reports & Analytics", icon: ListChecks },
  { href: "/categories", label: "Categories", icon: Trash2 },
  { href: "/settings", label: "Settings", icon: Leaf },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { darkMode, setDarkMode } = useTheme();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const activeHref = useMemo(() => {
    if (!pathname) return "/";
    return NAV.find((n) => n.href !== "/" && pathname.startsWith(n.href))?.href ?? "/";
  }, [pathname]);

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-72 transform border-r border-emerald-100 bg-white px-5 py-6 shadow-xl transition-transform duration-200 ease-in-out dark:border-slate-800 dark:bg-slate-900 md:relative md:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
        aria-label="Primary navigation"
      >
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-300">
              <Leaf className="h-6 w-6" aria-hidden />
            </span>
            <span>
              <span className="block text-lg font-semibold tracking-tight">EcoTrack</span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Smart waste monitoring
              </span>
            </span>
          </Link>
          <button
            type="button"
            className="md:hidden rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
            onClick={() => setOpen(false)}
            aria-label="Close navigation"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="mt-8 space-y-1">
          {NAV.map((item) => {
            const isActive =
              item.href === "/" ? pathname === "/" : activeHref === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-emerald-500/10 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-200"
                    : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                }`}
              >
                <Icon className="h-4 w-4" aria-hidden />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="mt-10 rounded-2xl bg-emerald-500/10 p-4 text-sm text-emerald-900 dark:text-emerald-100">
          <p className="font-semibold">EcoTrack</p>
          <p className="mt-1 text-xs leading-relaxed text-emerald-800/80 dark:text-emerald-100/80">
            An EVS engineering project for tracking waste, recycling, and environmental impact.
          </p>
        </div>
      </aside>

      {open && (
        <div
          className="fixed inset-0 z-30 bg-slate-900/40 md:hidden"
          onClick={() => setOpen(false)}
          aria-hidden
        />
      )}

      <div className="flex min-h-screen flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur dark:border-slate-800 dark:bg-slate-900/80 md:px-8">
          <div className="flex items-center gap-3">
            <button
              type="button"
              className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800 md:hidden"
              onClick={() => setOpen(true)}
              aria-label="Open navigation"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <p className="text-xs uppercase tracking-wider text-emerald-600 dark:text-emerald-300">
                EcoTrack
              </p>
              <h1 className="text-base font-semibold md:text-lg">
                {NAV.find((n) => n.href === activeHref)?.label ?? "Dashboard"}
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-200 md:inline-flex">
              Sample dataset
            </span>
            <button
              type="button"
              onClick={() => setDarkMode(!darkMode)}
              className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
              aria-label="Toggle colour theme"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
        </header>

        <main className="flex-1 px-4 py-6 md:px-8 md:py-8">{children}</main>

        <footer className="px-4 py-6 text-center text-xs text-slate-500 dark:text-slate-400 md:px-8">
          EcoTrack · Built for an EVS engineering project · Sample data only.
        </footer>
      </div>
    </div>
  );
}