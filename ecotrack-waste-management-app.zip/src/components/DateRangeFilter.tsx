"use client";

import { useEffect, useMemo, useState } from "react";
import { Calendar, Filter, RotateCcw } from "lucide-react";

export interface DateRangeValue {
  start: string | null;
  end: string | null;
}

interface Props {
  value: DateRangeValue;
  onChange: (next: DateRangeValue) => void;
}

export function DateRangeFilter({ value, onChange }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <Filter className="h-4 w-4 text-emerald-600" aria-hidden />
      <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
        Range
      </span>
      <input
        type="date"
        value={value.start ?? ""}
        onChange={(e) => onChange({ ...value, start: e.target.value || null })}
        className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-sm focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
        aria-label="Start date"
      />
      <span className="text-slate-400">→</span>
      <input
        type="date"
        value={value.end ?? ""}
        onChange={(e) => onChange({ ...value, end: e.target.value || null })}
        className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-sm focus:border-emerald-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800"
        aria-label="End date"
      />
      {(value.start || value.end) && (
        <button
          type="button"
          onClick={() => onChange({ start: null, end: null })}
          className="ml-1 inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <RotateCcw className="h-3 w-3" /> Reset
        </button>
      )}
    </div>
  );
}

export function useDateRange(initial?: DateRangeValue): [DateRangeValue, (v: DateRangeValue) => void] {
  const [state, setState] = useState<DateRangeValue>(initial ?? { start: null, end: null });
  const value = useMemo(() => state, [state]);
  return [value, setState];
}

export function useDebouncedValue<T>(value: T, delay = 250): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function formatDate(iso: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export { Calendar };