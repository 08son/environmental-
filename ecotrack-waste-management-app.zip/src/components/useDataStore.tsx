"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Goal, Settings, WasteRecord } from "@/lib/types";

interface ToastEntry {
  id: number;
  type: "success" | "error" | "info";
  message: string;
}

interface DataStoreValue {
  records: WasteRecord[];
  goals: Goal[];
  settings: Settings | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  createRecord: (
    input: Omit<WasteRecord, "id" | "createdAt" | "updatedAt" | "userId">,
  ) => Promise<WasteRecord | null>;
  updateRecord: (
    id: number,
    input: Omit<WasteRecord, "id" | "createdAt" | "updatedAt" | "userId">,
  ) => Promise<WasteRecord | null>;
  deleteRecord: (id: number) => Promise<boolean>;
  createGoal: (
    input: Omit<Goal, "id" | "userId" | "createdAt">,
  ) => Promise<Goal | null>;
  deleteGoal: (id: number) => Promise<boolean>;
  saveSettings: (patch: Partial<Settings>) => Promise<void>;
  toasts: ToastEntry[];
  dismissToast: (id: number) => void;
  notify: (type: ToastEntry["type"], message: string) => void;
}

const DataStore = createContext<DataStoreValue | null>(null);

const DEFAULT_SETTINGS: Settings = {
  emissionFactorPlastic: 2.5,
  emissionFactorPaper: 0.95,
  emissionFactorOrganic: 0.5,
  emissionFactorMetal: 4.0,
  emissionFactorGlass: 0.8,
  showEmissions: true,
  darkMode: false,
};

export function DataStoreProvider({ children }: { children: ReactNode }) {
  const [records, setRecords] = useState<WasteRecord[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastEntry[]>([]);

  const notify = useCallback((type: ToastEntry["type"], message: string) => {
    const id = Date.now() + Math.random();
    setToasts((cur) => [...cur, { id, type, message }]);
    setTimeout(() => {
      setToasts((cur) => cur.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((cur) => cur.filter((t) => t.id !== id));
  }, []);

  const refresh = useCallback(async () => {
    try {
      setError(null);
      const [rRes, gRes, sRes] = await Promise.all([
        fetch("/api/records", { cache: "no-store" }),
        fetch("/api/goals", { cache: "no-store" }),
        fetch("/api/settings", { cache: "no-store" }),
      ]);
      const rJson = await rRes.json();
      const gJson = await gRes.json();
      const sJson = await sRes.json();
      if (!rRes.ok) throw new Error(rJson.error ?? "Failed to load records");
      if (!gRes.ok) throw new Error(gJson.error ?? "Failed to load goals");
      if (!sRes.ok) throw new Error(sJson.error ?? "Failed to load settings");
      setRecords(rJson.records ?? []);
      setGoals(gJson.goals ?? []);
      setSettings({ ...DEFAULT_SETTINGS, ...(sJson.settings ?? {}) });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const createRecord = useCallback<DataStoreValue["createRecord"]>(
    async (input) => {
      try {
        const res = await fetch("/api/records", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to save");
        setRecords((cur) => [data.record, ...cur]);
        notify("success", "Waste record added");
        return data.record as WasteRecord;
      } catch (err) {
        notify("error", (err as Error).message);
        return null;
      }
    },
    [notify],
  );

  const updateRecord = useCallback<DataStoreValue["updateRecord"]>(
    async (id, input) => {
      try {
        const res = await fetch(`/api/records/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to update");
        setRecords((cur) =>
          cur.map((r) => (r.id === id ? (data.record as WasteRecord) : r)),
        );
        notify("success", "Record updated");
        return data.record as WasteRecord;
      } catch (err) {
        notify("error", (err as Error).message);
        return null;
      }
    },
    [notify],
  );

  const deleteRecord = useCallback<DataStoreValue["deleteRecord"]>(
    async (id) => {
      try {
        const res = await fetch(`/api/records?id=${id}`, {
          method: "DELETE",
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to delete");
        setRecords((cur) => cur.filter((r) => r.id !== id));
        notify("success", "Record removed");
        return true;
      } catch (err) {
        notify("error", (err as Error).message);
        return false;
      }
    },
    [notify],
  );

  const createGoal = useCallback<DataStoreValue["createGoal"]>(
    async (input) => {
      try {
        const res = await fetch("/api/goals", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to save goal");
        setGoals((cur) => [...cur, data.goal]);
        notify("success", "Goal created");
        return data.goal as Goal;
      } catch (err) {
        notify("error", (err as Error).message);
        return null;
      }
    },
    [notify],
  );

  const deleteGoal = useCallback<DataStoreValue["deleteGoal"]>(
    async (id) => {
      try {
        const res = await fetch(`/api/goals?id=${id}`, { method: "DELETE" });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to delete goal");
        setGoals((cur) => cur.filter((g) => g.id !== id));
        notify("success", "Goal removed");
        return true;
      } catch (err) {
        notify("error", (err as Error).message);
        return false;
      }
    },
    [notify],
  );

  const saveSettings = useCallback<DataStoreValue["saveSettings"]>(
    async (patch) => {
      try {
        const res = await fetch("/api/settings", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patch),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Failed to save settings");
        setSettings((cur) => ({ ...DEFAULT_SETTINGS, ...(cur ?? {}), ...data.settings }));
        notify("success", "Settings saved");
      } catch (err) {
        notify("error", (err as Error).message);
      }
    },
    [notify],
  );

  const value = useMemo<DataStoreValue>(
    () => ({
      records,
      goals,
      settings,
      loading,
      error,
      refresh,
      createRecord,
      updateRecord,
      deleteRecord,
      createGoal,
      deleteGoal,
      saveSettings,
      toasts,
      dismissToast,
      notify,
    }),
    [
      records,
      goals,
      settings,
      loading,
      error,
      refresh,
      createRecord,
      updateRecord,
      deleteRecord,
      createGoal,
      deleteGoal,
      saveSettings,
      toasts,
      dismissToast,
      notify,
    ],
  );

  return <DataStore.Provider value={value}>{children}</DataStore.Provider>;
}

export function useDataStore() {
  const ctx = useContext(DataStore);
  if (!ctx) throw new Error("useDataStore must be inside DataStoreProvider");
  return ctx;
}