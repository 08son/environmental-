import {
  pgTable,
  serial,
  text,
  timestamp,
  numeric,
  integer,
  date,
  pgEnum,
} from "drizzle-orm/pg-core";
import { sql as dsql } from "drizzle-orm";

export const wasteCategoryEnum = pgEnum("waste_category", [
  "wet_organic",
  "dry",
  "recyclable",
  "plastic",
  "paper",
  "glass",
  "metal",
  "ewaste",
  "hazardous",
  "other",
]);

export const processingMethodEnum = pgEnum("processing_method", [
  "composting",
  "recycling",
  "incineration",
  "landfill",
  "donation",
  "storage",
  "other",
]);

export const statusEnum = pgEnum("processing_status", [
  "collected",
  "in_process",
  "recycled",
  "composted",
  "disposed",
  "awaiting",
]);

export const wasteRecords = pgTable("waste_records", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("default"),
  category: wasteCategoryEnum("category").notNull(),
  description: text("description").notNull(),
  weightKg: numeric("weight_kg", { precision: 10, scale: 2 }).notNull(),
  collectionDate: date("collection_date").notNull(),
  location: text("location").notNull(),
  processingMethod: processingMethodEnum("processing_method").notNull(),
  status: statusEnum("status").notNull().default("collected"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .default(dsql`now()`),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .default(dsql`now()`),
});

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().default("default"),
  type: text("type").notNull(), // reduce, recycle, compost
  targetKg: numeric("target_kg", { precision: 10, scale: 2 }).notNull(),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .default(dsql`now()`),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique().default("default"),
  emissionFactorPlastic: numeric("emission_factor_plastic", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("2.5"),
  emissionFactorPaper: numeric("emission_factor_paper", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("0.9"),
  emissionFactorOrganic: numeric("emission_factor_organic", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("0.5"),
  emissionFactorMetal: numeric("emission_factor_metal", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("4.0"),
  emissionFactorGlass: numeric("emission_factor_glass", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("0.8"),
  showEmissions: integer("show_emissions").notNull().default(1),
  darkMode: integer("dark_mode").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .default(dsql`now()`),
});

export type WasteRecord = typeof wasteRecords.$inferSelect;
export type NewWasteRecord = typeof wasteRecords.$inferInsert;
export type Goal = typeof goals.$inferSelect;
export type NewGoal = typeof goals.$inferInsert;
export type Settings = typeof settings.$inferSelect;