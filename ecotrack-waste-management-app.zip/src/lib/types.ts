import type {
  ProcessingMethod,
  ProcessingStatus,
  WasteCategoryKey,
} from "./categories";

export interface WasteRecord {
  id: number;
  userId?: string;
  description: string;
  category: WasteCategoryKey;
  weightKg: number;
  collectionDate: string; // ISO yyyy-mm-dd
  location: string;
  processingMethod: ProcessingMethod;
  status: ProcessingStatus;
  notes?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Goal {
  id: number;
  userId?: string;
  type: "reduce" | "recycle" | "compost";
  title: string;
  targetKg: number;
  periodStart: string;
  periodEnd: string;
  createdAt: string;
}

export interface Settings {
  emissionFactorPlastic: number;
  emissionFactorPaper: number;
  emissionFactorOrganic: number;
  emissionFactorMetal: number;
  emissionFactorGlass: number;
  showEmissions: boolean;
  darkMode: boolean;
}