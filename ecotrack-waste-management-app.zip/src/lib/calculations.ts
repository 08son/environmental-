import {
  CATEGORY_MAP,
  HAZARDOUS_CATEGORIES,
  ORGANIC_CATEGORIES,
  RECYCLABLE_CATEGORIES,
  type WasteCategoryKey,
} from "./categories";
import type { Goal, WasteRecord } from "./types";

// Statuses that mean the material has been diverted from disposal.
export const RECYCLED_STATUSES = ["recycled"] as const;
export const COMPOSTED_STATUSES = ["composted"] as const;
export const DISPOSED_STATUSES = ["disposed"] as const;
export const DIVERTED_STATUSES = ["recycled", "composted", "donation", "in_process"] as const;

export interface DashboardSummary {
  totalKg: number;
  recyclableKg: number;
  organicKg: number;
  dryKg: number;
  divertedKg: number;
  recycledKg: number;
  compostedKg: number;
  disposedKg: number;
  recordCount: number;
  recyclingRate: number; // %
  compostingRate: number; // %
  diversionRate: number; // %
  hazardousKg: number;
}

function safeDiv(a: number, b: number): number {
  if (!b || Number.isNaN(b)) return 0;
  return a / b;
}

export function summarise(records: WasteRecord[]): DashboardSummary {
  let totalKg = 0;
  let recyclableKg = 0;
  let organicKg = 0;
  let dryKg = 0;
  let divertedKg = 0;
  let recycledKg = 0;
  let compostedKg = 0;
  let disposedKg = 0;
  let hazardousKg = 0;

  for (const r of records) {
    const w = Number(r.weightKg) || 0;
    if (w <= 0) continue;
    totalKg += w;
    if (RECYCLABLE_CATEGORIES.includes(r.category)) recyclableKg += w;
    if (ORGANIC_CATEGORIES.includes(r.category)) organicKg += w;
    if (r.category === "dry") dryKg += w;
    if (HAZARDOUS_CATEGORIES.includes(r.category)) hazardousKg += w;
    if (RECYCLED_STATUSES.includes(r.status as never)) recycledKg += w;
    if (COMPOSTED_STATUSES.includes(r.status as never)) compostedKg += w;
    if (DISPOSED_STATUSES.includes(r.status as never)) disposedKg += w;
    if (DIVERTED_STATUSES.includes(r.status as never)) divertedKg += w;
  }

  return {
    totalKg,
    recyclableKg,
    organicKg,
    dryKg,
    divertedKg,
    recycledKg,
    compostedKg,
    disposedKg,
    hazardousKg,
    recordCount: records.length,
    recyclingRate: safeDiv(recycledKg, totalKg) * 100,
    compostingRate: safeDiv(compostedKg, totalKg) * 100,
    diversionRate: safeDiv(divertedKg, totalKg) * 100,
  };
}

export interface CategoryBreakdown {
  category: WasteCategoryKey;
  label: string;
  color: string;
  totalKg: number;
  count: number;
  percent: number;
}

export function byCategory(records: WasteRecord[]): CategoryBreakdown[] {
  const totals = new Map<WasteCategoryKey, { total: number; count: number }>();
  let grand = 0;
  for (const r of records) {
    const w = Number(r.weightKg) || 0;
    if (w <= 0) continue;
    grand += w;
    const cur = totals.get(r.category) ?? { total: 0, count: 0 };
    cur.total += w;
    cur.count += 1;
    totals.set(r.category, cur);
  }
  const out: CategoryBreakdown[] = [];
  for (const meta of Object.values(CATEGORY_MAP)) {
    const t = totals.get(meta.key);
    if (!t || t.total <= 0) continue;
    out.push({
      category: meta.key,
      label: meta.label,
      color: meta.color,
      totalKg: t.total,
      count: t.count,
      percent: safeDiv(t.total, grand) * 100,
    });
  }
  return out.sort((a, b) => b.totalKg - a.totalKg);
}

export interface DailyPoint {
  date: string;
  totalKg: number;
  recycledKg: number;
  compostedKg: number;
}

export function byDay(records: WasteRecord[]): DailyPoint[] {
  const map = new Map<string, DailyPoint>();
  for (const r of records) {
    const w = Number(r.weightKg) || 0;
    if (w <= 0) continue;
    const cur =
      map.get(r.collectionDate) ??
      { date: r.collectionDate, totalKg: 0, recycledKg: 0, compostedKg: 0 };
    cur.totalKg += w;
    if (RECYCLED_STATUSES.includes(r.status as never)) cur.recycledKg += w;
    if (COMPOSTED_STATUSES.includes(r.status as never)) cur.compostedKg += w;
    map.set(r.collectionDate, cur);
  }
  return Array.from(map.values()).sort((a, b) =>
    a.date.localeCompare(b.date),
  );
}

export interface MonthlyPoint {
  month: string; // yyyy-mm
  label: string;
  totalKg: number;
  recycledKg: number;
  compostedKg: number;
  disposedKg: number;
}

export function byMonth(records: WasteRecord[]): MonthlyPoint[] {
  const map = new Map<string, MonthlyPoint>();
  for (const r of records) {
    const w = Number(r.weightKg) || 0;
    if (w <= 0) continue;
    const ym = r.collectionDate.slice(0, 7);
    const cur =
      map.get(ym) ??
      {
        month: ym,
        label: new Date(ym + "-01").toLocaleString("en-US", {
          month: "short",
          year: "numeric",
        }),
        totalKg: 0,
        recycledKg: 0,
        compostedKg: 0,
        disposedKg: 0,
      };
    cur.totalKg += w;
    if (RECYCLED_STATUSES.includes(r.status as never)) cur.recycledKg += w;
    if (COMPOSTED_STATUSES.includes(r.status as never)) cur.compostedKg += w;
    if (DISPOSED_STATUSES.includes(r.status as never)) cur.disposedKg += w;
    map.set(ym, cur);
  }
  return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
}

export function recyclingVsDisposal(byMonthData: MonthlyPoint[]) {
  return byMonthData.map((m) => ({
    month: m.label,
    Recycled: m.recycledKg,
    Composted: m.compostedKg,
    Disposed: m.disposedKg,
  }));
}

export function isInDateRange(
  dateIso: string,
  start: string | null,
  end: string | null,
): boolean {
  if (start && dateIso < start) return false;
  if (end && dateIso > end) return false;
  return true;
}

export interface Recommendation {
  id: string;
  severity: "info" | "warning" | "success";
  title: string;
  message: string;
}

export function generateRecommendations(
  records: WasteRecord[],
  goals: Goal[],
): Recommendation[] {
  const recs: Recommendation[] = [];
  const summary = summarise(records);
  const cats = byCategory(records);
  const months = byMonth(records);
  const totalByKey = (key: WasteCategoryKey) =>
    cats.find((c) => c.category === key)?.totalKg ?? 0;

  // Plastic-heavy
  const plastic = totalByKey("plastic");
  if (plastic > 0 && summary.totalKg > 0 && plastic / summary.totalKg > 0.2) {
    recs.push({
      id: "plastic-heavy",
      severity: "warning",
      title: "High plastic share detected",
      message: `Plastic accounts for ${((plastic / summary.totalKg) * 100).toFixed(
        1,
      )}% of total waste. Consider reusable bottles, bags, and containers, and add a dedicated plastic collection bin.`,
    });
  }
  // Organic-heavy
  const organic = totalByKey("wet_organic");
  if (
    organic > 0 &&
    summary.totalKg > 0 &&
    organic / summary.totalKg > 0.25 &&
    summary.compostingRate < 25
  ) {
    recs.push({
      id: "organic-heavy",
      severity: "warning",
      title: "Organic waste under-composted",
      message: `Wet/organic waste makes up ${((organic / summary.totalKg) * 100).toFixed(
        1,
      )}% of total waste, but composting rate is only ${summary.compostingRate.toFixed(
        1,
      )}%. Set up segregated bins and start a composting pit or bin.`,
    });
  }
  // Paper-heavy
  const paper = totalByKey("paper");
  if (paper > 0 && summary.totalKg > 0 && paper / summary.totalKg > 0.15) {
    recs.push({
      id: "paper-heavy",
      severity: "info",
      title: "Paper waste is significant",
      message: `Paper contributes ${((paper / summary.totalKg) * 100).toFixed(
        1,
      )}% of waste. Promote double-sided printing, digital notes, and ensure paper is sent for pulping.`,
    });
  }
  // Declining recycling rate
  if (months.length >= 2) {
    const last = months[months.length - 1];
    const prev = months[months.length - 2];
    const lastRate =
      last.totalKg > 0 ? ((last.recycledKg + last.compostedKg) / last.totalKg) * 100 : 0;
    const prevRate =
      prev.totalKg > 0 ? ((prev.recycledKg + prev.compostedKg) / prev.totalKg) * 100 : 0;
    if (lastRate < prevRate - 5) {
      recs.push({
        id: "declining-recycling",
        severity: "warning",
        title: "Recycling rate is trending down",
        message: `Diversion rate fell from ${prevRate.toFixed(1)}% to ${lastRate.toFixed(
          1,
        )}% between ${prev.label} and ${last.label}. Audit collection bins and refresh segregation signage.`,
      });
    }
  }
  // Goals
  for (const goal of goals) {
    const period = records.filter(
      (r) => r.collectionDate >= goal.periodStart && r.collectionDate <= goal.periodEnd,
    );
    const total = period.reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
    const recycled = period
      .filter((r) => RECYCLED_STATUSES.includes(r.status as never))
      .reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
    const composted = period
      .filter((r) => COMPOSTED_STATUSES.includes(r.status as never))
      .reduce((a, r) => a + (Number(r.weightKg) || 0), 0);
    let achieved = 0;
    let label = "";
    if (goal.type === "reduce") {
      achieved = total;
      label = `Total waste so far ${total.toFixed(1)} kg`;
    } else if (goal.type === "recycle") {
      achieved = recycled;
      label = `Recycled ${recycled.toFixed(1)} kg of ${goal.targetKg} kg`;
    } else {
      achieved = composted;
      label = `Composted ${composted.toFixed(1)} kg of ${goal.targetKg} kg`;
    }
    const progress = Math.min(100, (achieved / goal.targetKg) * 100);
    const remaining = Math.max(0, goal.targetKg - achieved);
    if (progress >= 100) {
      recs.push({
        id: `goal-met-${goal.id}`,
        severity: "success",
        title: `Goal achieved: ${goal.title}`,
        message: `${label}. Congratulations — set a new stretch target.`,
      });
    } else if (new Date(goal.periodEnd) < new Date()) {
      recs.push({
        id: `goal-missed-${goal.id}`,
        severity: "warning",
        title: `Goal missed: ${goal.title}`,
        message: `${label}. Short by ${remaining.toFixed(1)} kg. Try smaller sub-goals or weekly tracking.`,
      });
    } else {
      recs.push({
        id: `goal-progress-${goal.id}`,
        severity: "info",
        title: `In progress: ${goal.title}`,
        message: `${label}. ${remaining.toFixed(
          1,
        )} kg remaining (${progress.toFixed(0)}% of target).`,
      });
    }
  }
  if (recs.length === 0) {
    recs.push({
      id: "all-good",
      severity: "success",
      title: "Looking good",
      message:
        "Not enough data to surface recommendations. Add more records to unlock personalised tips.",
    });
  }
  return recs;
}

export function exportCsv(records: WasteRecord[]): string {
  const headers = [
    "Record ID",
    "Date",
    "Category",
    "Description",
    "Weight (kg)",
    "Location",
    "Processing Method",
    "Status",
    "Notes",
    "Created At",
  ];
  const rows = records.map((r) =>
    [
      r.id,
      r.collectionDate,
      r.category,
      `"${r.description.replace(/"/g, '""')}"`,
      r.weightKg,
      `"${r.location.replace(/"/g, '""')}"`,
      r.processingMethod,
      r.status,
      `"${(r.notes ?? "").replace(/"/g, '""')}"`,
      r.createdAt,
    ].join(","),
  );
  return [headers.join(","), ...rows].join("\n");
}

export function downloadCsv(filename: string, csv: string) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Carbon estimate (demonstration only) using kgCO2e per kg of material diverted from landfill.
export function estimateCarbonAvoided(
  records: WasteRecord[],
  settings: {
    emissionFactorPlastic: number;
    emissionFactorPaper: number;
    emissionFactorOrganic: number;
    emissionFactorMetal: number;
    emissionFactorGlass: number;
  },
): number {
  let total = 0;
  for (const r of records) {
    const w = Number(r.weightKg) || 0;
    if (w <= 0) continue;
    if (!DIVERTED_STATUSES.includes(r.status as never)) continue;
    switch (r.category) {
      case "plastic":
        total += w * Number(settings.emissionFactorPlastic);
        break;
      case "paper":
        total += w * Number(settings.emissionFactorPaper);
        break;
      case "wet_organic":
        total += w * Number(settings.emissionFactorOrganic);
        break;
      case "metal":
        total += w * Number(settings.emissionFactorMetal);
        break;
      case "glass":
        total += w * Number(settings.emissionFactorGlass);
        break;
      default:
        total += w * 1.0;
    }
  }
  return total;
}