export type WasteCategoryKey =
  | "wet_organic"
  | "dry"
  | "recyclable"
  | "plastic"
  | "paper"
  | "glass"
  | "metal"
  | "ewaste"
  | "hazardous"
  | "other";

export type ProcessingMethod =
  | "composting"
  | "recycling"
  | "incineration"
  | "landfill"
  | "donation"
  | "storage"
  | "other";

export type ProcessingStatus =
  | "collected"
  | "in_process"
  | "recycled"
  | "composted"
  | "disposed"
  | "awaiting";

export interface WasteCategoryMeta {
  key: WasteCategoryKey;
  label: string;
  color: string;
  description: string;
  safetyNote?: string;
  isRecyclable: boolean;
  isOrganic: boolean;
}

export const WASTE_CATEGORIES: WasteCategoryMeta[] = [
  {
    key: "wet_organic",
    label: "Wet / Organic",
    color: "#16a34a",
    description:
      "Food scraps, vegetable peels, garden waste, and other biodegradable matter.",
    isRecyclable: false,
    isOrganic: true,
  },
  {
    key: "dry",
    label: "Dry Waste",
    color: "#65a30d",
    description: "Non-biodegradable, non-recyclable dry items such as foam dust.",
    isRecyclable: false,
    isOrganic: false,
  },
  {
    key: "recyclable",
    label: "Recyclable",
    color: "#0ea5e9",
    description: "Mixed materials marked for recycling.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "plastic",
    label: "Plastic",
    color: "#0284c7",
    description: "PET bottles, wrappers, bags, and other plastic items.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "paper",
    label: "Paper & Cardboard",
    color: "#ca8a04",
    description: "Newspapers, books, cartons, and cardboard boxes.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "glass",
    label: "Glass",
    color: "#7c3aed",
    description: "Bottles, jars, and other glass containers.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "metal",
    label: "Metal",
    color: "#475569",
    description: "Aluminium cans, steel items, and scrap metal.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "ewaste",
    label: "Electronic (e-waste)",
    color: "#db2777",
    description: "Phones, batteries, cables, and small appliances.",
    safetyNote:
      "Do not mix e-waste with regular waste. Take to an authorised e-waste collection centre.",
    isRecyclable: true,
    isOrganic: false,
  },
  {
    key: "hazardous",
    label: "Hazardous",
    color: "#dc2626",
    description: "Paint, chemicals, medical waste, and other hazardous items.",
    safetyNote:
      "Never mix hazardous waste with ordinary waste. Store separately and hand over to a licensed hazardous waste handler.",
    isRecyclable: false,
    isOrganic: false,
  },
  {
    key: "other",
    label: "Other",
    color: "#64748b",
    description: "Items that do not fit in any other category.",
    isRecyclable: false,
    isOrganic: false,
  },
];

export const CATEGORY_MAP: Record<WasteCategoryKey, WasteCategoryMeta> =
  Object.fromEntries(WASTE_CATEGORIES.map((c) => [c.key, c])) as Record<
    WasteCategoryKey,
    WasteCategoryMeta
  >;

export const PROCESSING_METHODS: { key: ProcessingMethod; label: string }[] = [
  { key: "composting", label: "Composting" },
  { key: "recycling", label: "Recycling" },
  { key: "incineration", label: "Incineration" },
  { key: "landfill", label: "Landfill" },
  { key: "donation", label: "Donation / Reuse" },
  { key: "storage", label: "Storage / Awaiting Pickup" },
  { key: "other", label: "Other" },
];

export const PROCESSING_STATUSES: {
  key: ProcessingStatus;
  label: string;
  color: string;
}[] = [
  { key: "collected", label: "Collected", color: "#0284c7" },
  { key: "in_process", label: "In Process", color: "#ca8a04" },
  { key: "recycled", label: "Recycled", color: "#16a34a" },
  { key: "composted", label: "Composted", color: "#15803d" },
  { key: "disposed", label: "Disposed", color: "#dc2626" },
  { key: "awaiting", label: "Awaiting Pickup", color: "#7c3aed" },
];

export const STATUS_MAP: Record<ProcessingStatus, { label: string; color: string }> =
  Object.fromEntries(
    PROCESSING_STATUSES.map((s) => [s.key, { label: s.label, color: s.color }]),
  ) as Record<ProcessingStatus, { label: string; color: string }>;

// Classification helpers used in calculations so each kg is only counted once.
export const RECYCLABLE_CATEGORIES: WasteCategoryKey[] = [
  "recyclable",
  "plastic",
  "paper",
  "glass",
  "metal",
  "ewaste",
];

export const ORGANIC_CATEGORIES: WasteCategoryKey[] = ["wet_organic"];

export const HAZARDOUS_CATEGORIES: WasteCategoryKey[] = [
  "hazardous",
  "ewaste",
];